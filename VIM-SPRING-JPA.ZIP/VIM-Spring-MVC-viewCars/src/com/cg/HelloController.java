package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;

@Controller
@RequestMapping("/*")
public class HelloController {

	@RequestMapping(method=RequestMethod.GET, value="hello")
	@ResponseBody
	public String sayHello(){
		return "Hello, world!!!";
	}
	
	@Autowired
	private CarDAO carDAO;
	
	@RequestMapping(method=RequestMethod.GET, value="controller")
//	@ResponseBody
	public String getCarMake(@RequestParam("action") String action, @ModelAttribute("car")CarDTO car, 
		      BindingResult result, ModelMap model){
		if(action.equals("viewCarList")){
			return "carList";
		}
	
		if(action.equals("addCar")){
			return "carForm";
		}
		
		
		
		return carDAO.findAll().get(0).getMake();
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="controller")
//	@ResponseBody
	public String addCarMake(@RequestParam("action") String action, @ModelAttribute("car")CarDTO car, 
		      BindingResult result, ModelMap model){
		
		if(action.equals("saveCar")){
			
			
			System.out.println(car.getMake());
			
			carDAO.create(car);
			model.addAttribute("carList",carDAO.findAll());
			
			return "carList";
		}
		
		
		
		
		return null;
	}
	
	
	@ModelAttribute("carList")
	public List<CarDTO> getCars(){
		System.out.println("Finding cars from db");
		return carDAO.findAll();
	}
	
	
	
	
	
	
	
	
}

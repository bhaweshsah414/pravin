package com.cg.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;

@Repository
@Transactional
public class JPACarDAO implements CarDAO{
	
/*	@PersistenceContext
	private EntityManager entityManager;
*/
	
	@PersistenceUnit(unitName = "VIMApp")
	private EntityManagerFactory entityManagerFactory;
	
	@Override
	public List<CarDTO> findAll() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Query query=entityManager.createQuery("select car from CarDTO car");
		return query.getResultList();
	}

	@Override
	public CarDTO findById(int id) {

		/*Query query=entityManager.createQuery();*/
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		
		CarDTO car=(CarDTO)entityManager.find(CarDTO.class,id);
		entityManager.getTransaction().commit();
		return car;
	}

	@Override
	@Transactional
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
//		System.out.println(car.getMake()+ " in DAO layer");
		entityManager.persist(car);
		entityManager.flush();
		System.out.println(car.getId());
		System.out.println(car.getMake()+ " in DAO layer");
		
		entityManager.getTransaction().commit();
		/*
		Query query=entityManager.createNativeQuery("select caridsequence.nextval from dual");
		BigDecimal id= (BigDecimal) query.getSingleResult();
		int i=id.intValue();
		System.out.println(i);
		car.setId(i);*/
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("");
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}

	

	

	
}

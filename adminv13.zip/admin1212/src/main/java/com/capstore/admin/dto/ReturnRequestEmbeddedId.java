package com.capstore.admin.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ReturnRequestEmbeddedId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "customerid")
	private int customerId;
	
	@Column(name = "productid")
	private int productid;
	
	@Column(name = "orderid")
	private int orderId;

	public ReturnRequestEmbeddedId() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
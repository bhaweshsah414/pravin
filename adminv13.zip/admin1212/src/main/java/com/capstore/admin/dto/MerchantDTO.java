package com.capstore.admin.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="merchantdetail")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MerchantDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="merchantid")
	private int merchantId;
	@Column(name="merchantname")
	private String merchantName;
	@Column(name="merchantemail")
	private String email;
	@Column(name="merchantaddress")
	private String address;
	@Column(name="storename")
	private String storeName;
	@Column(name="mobileno")
	private String mobileNo;
	@Column(name="merchantrating")
	private Double merchantRating;
	@Column(name="merchantfeedback")
	private String merchantFeedback;
	
	public MerchantDTO() {
		// TODO Auto-generated constructor stub
	}
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
	private List<ProductDTO> products;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
	private List<OfferDTO> offers;
	@OneToMany(fetch = FetchType.LAZY, mappedBy="merchants")
	private List<OrderDTO> orders;
	
	@JsonBackReference
	public List<ProductDTO> getProducts() {
		return products;
	}
	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	@JsonManagedReference
	public List<OfferDTO> getOffers() {
		return offers;
	}
	public void setOffers(List<OfferDTO> offers) {
		this.offers = offers;
	}
	@JsonBackReference
	public List<OrderDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Double getMerchantRating() {
		return merchantRating;
	}
	public void setMerchantRating(Double merchantRating) {
		this.merchantRating = merchantRating;
	}
	public String getMerchantFeedback() {
		return merchantFeedback;
	}
	public void setMerchantFeedback(String merchantFeedback) {
		this.merchantFeedback = merchantFeedback;
	}
	
	
}

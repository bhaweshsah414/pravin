package com.capstore.admin.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.capstore.admin.dto.CustomerDTO;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
@Table(name="orderdetail")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class OrderDTO {

	@Id
	@Column(name="orderid")
	private int orderId;
	@Column(name="orderdate")
	private Date orderDate;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="totalprice")
	private int totalPrice;
	@Column(name="finalprice")
	private int finalPrice;
	
	@JsonIgnore
	@ManyToOne(targetEntity = CustomerDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="customerid", insertable=false, updatable=false)
	private CustomerDTO customers;
	
	@ManyToOne(targetEntity = MerchantDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name="merchantid", insertable=false, updatable=false)
	private MerchantDTO merchants;
	
	@ManyToOne(targetEntity = ProductDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name="productid", insertable=false, updatable=false)
	private ProductDTO products;

	public OrderDTO() {
		// TODO Auto-generated constructor stub
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}
	public CustomerDTO getCustomer() {
		return customers;
	}
	@JsonManagedReference
	public void setCustomer(CustomerDTO customer) {
		this.customers = customer;
	}
	@JsonBackReference
	public MerchantDTO getMerchant() {
		return merchants;
	}
	@JsonManagedReference
	public void setMerchant(MerchantDTO merchant) {
		this.merchants = merchant;
	}
	@JsonManagedReference
	public ProductDTO getProduct() {
		return products;
	}
	@JsonManagedReference
	public void setProduct(ProductDTO product) {
		this.products = product;
	}
	
	
}

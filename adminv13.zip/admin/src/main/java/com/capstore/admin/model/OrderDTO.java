package com.capstore.admin.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="orderdetail")
public class OrderDTO {

	@Id
	@Column(name="orderid")
	private int orderId;
	@Column(name="orderdate")
	private Date orderDate;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="totalprice")
	private int totalPrice;
	@Column(name="finalprice")
	private int finalPrice;
	
	@ManyToOne(targetEntity = CustomerDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="customerid")
	//@JsonBackReference("customerorder")
	private CustomerDTO customers;
	@ManyToOne(targetEntity = MerchantDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name="merchantid")
	//@JsonBackReference("merchantorder")
	private MerchantDTO merchants;
	@ManyToOne(targetEntity = ProductDTO.class,fetch = FetchType.LAZY)
	@JoinColumn(name="productid")
	@JsonBackReference("productorder")
	private ProductDTO products;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}
	public CustomerDTO getCustomer() {
		return customers;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customers = customer;
	}
	public MerchantDTO getMerchant() {
		return merchants;
	}
	public void setMerchant(MerchantDTO merchant) {
		this.merchants = merchant;
	}
	public ProductDTO getProduct() {
		return products;
	}
	public void setProduct(ProductDTO product) {
		this.products = product;
	}
	
	
}

package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.model.ReturnRequestDTO;
import com.capstore.admin.model.ReturnRequestKey;

public interface ReturnRequestRepository extends JpaRepository<ReturnRequestDTO, ReturnRequestKey> {

}


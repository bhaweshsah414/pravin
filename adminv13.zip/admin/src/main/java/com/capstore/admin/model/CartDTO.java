package com.capstore.admin.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="cart")
public class CartDTO{

	@Id
	@Column(name="customerid")
	private int customerid;
	@Column(name="productid")
	private int productid;
	@Column(name="promocode")
	private String promoCode;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="productprice")
	private int productPrice;
	@Column(name="softdelete")
	private String softdelete;
	
	@OneToMany(mappedBy="carts", fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<ProductDTO> product;
	

	
	public CartDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public List<ProductDTO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDTO> product) {
		this.product = product;
	}
	
	
	}

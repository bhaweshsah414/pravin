package com.cg.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import java.util.List;

import javax.persistence.*;
import com.cg.beans.CarDTO;
import com.cg.dao.CarDAO;
@Repository
public class JPACarDAO implements CarDAO{
	
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<CarDTO> findAll() {
		
		try{
		
		Query query = entityManager.createQuery("select car from CarDTO car");
		
		return query.getResultList();
		}
	finally{
	entityManager.close();	
	}
	}

	@Override
	public CarDTO findById(int id) {
		CarDTO car = (CarDTO)entityManager.find(CarDTO.class,id);
		return car;
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}
	









}	
	 /*EntityManagerFactory emf=Persistence.createEntityManagerFactory("Car");  
     EntityManager em=emf.createEntityManager();  
     
     em.getTransaction().begin(); 
       
     CarDTO s1=new CarDTO();  
     */
     
     /*s1.setS_id(101);  
     s1.setS_name("Gaurav");  
     s1.setS_age(24);  
     */  
     /*StudentEntity s2=new StudentEntity();  
     s2.setS_id(102);  
     s2.setS_name("Ronit");  
     s2.setS_age(22);  
       
     StudentEntity s3=new StudentEntity();  
     s3.setS_id(103);  
     s3.setS_name("Rahul");  
     s3.setS_age(26);  
       
     em.persist(s1);  
     em.persist(s2);  
     em.persist(s3);       

em.getTransaction().commit();  
       
     emf.close();  
     em.close();  
*/       
   

	


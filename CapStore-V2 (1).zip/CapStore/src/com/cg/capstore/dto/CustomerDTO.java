package com.cg.capstore.dto;

import java.util.List;

public class CustomerDTO {

	
	private int customerId;
	private String customerName;
	private String email;
	private String mobileNo;
	private String address;
	private int pinCode;
	
	private List<OrderDTO> orders;
	private WishlistDTO wishlist; 
	private CartDTO cart;
	
	public int getCustomerId() {
		return customerId;
	}
	public List<OrderDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDTO> orders) {
		this.orders = orders;
	}
	public WishlistDTO getWishlist() {
		return wishlist;
	}
	public void setWishlist(WishlistDTO wishlist) {
		this.wishlist = wishlist;
	}
	public CartDTO getCart() {
		return cart;
	}
	public void setCart(CartDTO cart) {
		this.cart = cart;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	
	
}

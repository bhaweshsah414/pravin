package com.cg.capstore.dto;

public enum ReturnStatus {
	
	AAPPLIED,
	APPROVED,
	REJECTED

}

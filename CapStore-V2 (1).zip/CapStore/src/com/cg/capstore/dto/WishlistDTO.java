package com.cg.capstore.dto;

import java.util.List;

public class WishlistDTO {
 
	private List<ProductDTO> products;
	
	private int productPrice;
	
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public List<ProductDTO> getProducts() {
		return products;
	}
	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
}

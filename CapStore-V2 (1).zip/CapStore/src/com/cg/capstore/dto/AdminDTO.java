package com.cg.capstore.dto;

import java.util.List;

public class AdminDTO {

	private int adminId;
	private String adminName;
	private String email;
	private String mobileNo;
	
	private List<PromoDTO> promos;
	private List<ReturnRequestDTO> returnRequests;
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public List<PromoDTO> getPromos() {
		return promos;
	}
	public void setPromos(List<PromoDTO> promos) {
		this.promos = promos;
	}
	public List<ReturnRequestDTO> getReturnRequests() {
		return returnRequests;
	}
	public void setReturnRequests(List<ReturnRequestDTO> returnRequests) {
		this.returnRequests = returnRequests;
	}
	
	
	
	
}

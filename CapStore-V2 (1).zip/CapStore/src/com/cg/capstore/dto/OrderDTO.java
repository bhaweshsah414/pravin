package com.cg.capstore.dto;

import java.util.Date;
import java.util.Map;

public class OrderDTO {

	
	private int orderId;
	private Date orderDate;
	private int productQuantity;
	private int totalPrice;
	private int finalPrice;
	
	private CustomerDTO customer;
	
	private Map<ProductDTO, MerchantDTO> map; 
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getFinalPrice() {
		return finalPrice;
	}
	public void setFinalPrice(int finalPrice) {
		this.finalPrice = finalPrice;
	}
	public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public Map<ProductDTO, MerchantDTO> getMap() {
		return map;
	}
	public void setMap(Map<ProductDTO, MerchantDTO> map) {
		this.map = map;
	}

	
}

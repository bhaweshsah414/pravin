package com.cg.capstore.dto;

import java.util.Date;

public class OfferDTO {

	private String offerDescription;
	private Date offerStartDate;
	private Date endStartDate;
	private int discountOffered;
	
	private MerchantDTO merchant;
	private ProductDTO product;
	
	public String getOfferDescription() {
		return offerDescription;
	}
	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}
	public Date getOfferStartDate() {
		return offerStartDate;
	}
	public void setOfferStartDate(Date offerStartDate) {
		this.offerStartDate = offerStartDate;
	}
	public Date getEndStartDate() {
		return endStartDate;
	}
	public void setEndStartDate(Date endStartDate) {
		this.endStartDate = endStartDate;
	}
	public int getDiscountOffered() {
		return discountOffered;
	}
	public void setDiscountOffered(int discountOffered) {
		this.discountOffered = discountOffered;
	}
	public MerchantDTO getMerchant() {
		return merchant;
	}
	public void setMerchant(MerchantDTO merchant) {
		this.merchant = merchant;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	
	
	
}

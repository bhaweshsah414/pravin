package com.capstore.admin.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="returnrequest")
public class ReturnRequestDTO {

	@Id
	private int refundamount;
	private String returnstatus;
	
	@ManyToOne(targetEntity= CustomerDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="customerid", insertable=false, updatable=false)
	private CustomerDTO customer;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="productid", insertable=false, updatable=false)
	private ProductDTO product;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="orderid")
	private OrderDTO order;
	
	@ManyToOne(targetEntity = AdminDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="returnstatus", insertable=false, updatable=false)
	private AdminDTO admins;
	
	public int getRefundAmount() {
		return refundamount;
	}
	public void setRefundAmount(int refundAmount) {
		this.refundamount = refundAmount;
	}
	public String getReturnStatus() {
		return returnstatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnstatus = returnStatus;
	}
	public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public OrderDTO getOrder() {
		return order;
	}
	public void setOrder(OrderDTO order) {
		this.order = order;
	}
	
	
}

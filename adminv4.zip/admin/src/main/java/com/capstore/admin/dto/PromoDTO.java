package com.capstore.admin.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="promo")
public class PromoDTO {

	@Id
	@Column(name="promocode")
	private String promoCode;
	private int discountoffered;
	private Date promovalidity;
	
	@ManyToOne(targetEntity = AdminDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name="promocode", insertable=false, updatable=false)
	private AdminDTO admins;
	
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getDiscountOffered() {
		return discountoffered;
	}
	public void setDiscountOdffered(int discountOffered) {
		this.discountoffered = discountOffered;
	}
	public Date getPromoValidity() {
		return promovalidity;
	}
	public void setPromoValidity(Date promoValidity) {
		this.promovalidity = promoValidity;
	}
	
	
}

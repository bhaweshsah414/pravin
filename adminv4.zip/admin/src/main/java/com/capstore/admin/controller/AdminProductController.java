package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.dto.ProductDTO;

import com.capstore.admin.repository.ProductRepository;


@RestController
@RequestMapping("api/v1")
	
	
	public class AdminProductController {
		
		@Autowired
		private ProductRepository productRepository;
		
		@RequestMapping(value = "products", method = RequestMethod.GET)
		public List<ProductDTO> list() {
			return productRepository.findAll();
		}

		@RequestMapping(value = "products", method = RequestMethod.POST)
		public ProductDTO create(@RequestBody ProductDTO ProductDTO) {
			return productRepository.saveAndFlush(ProductDTO);
		}

		@RequestMapping(value = "products/{id}", method = RequestMethod.GET)
		public ProductDTO get(@PathVariable Integer id) {
			return productRepository.findOne(id);
		}

		@RequestMapping(value = "products/{id}", method = RequestMethod.PUT)
		public ProductDTO update(@PathVariable Integer id, @RequestBody ProductDTO ProductDTO) {
			ProductDTO existingProduct = productRepository.findOne(id);
			BeanUtils.copyProperties(ProductDTO, existingProduct);
			return productRepository.saveAndFlush(existingProduct);
		}

		@RequestMapping(value = "products/{id}", method = RequestMethod.DELETE)
		public ProductDTO delete(@PathVariable Integer id) {
			ProductDTO existingProduct = productRepository.findOne(id);
			productRepository.delete(existingProduct);
			return existingProduct;
		}
	
	

}

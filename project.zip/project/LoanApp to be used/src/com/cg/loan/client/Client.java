package com.cg.loan.client;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanProgramBean;
import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;

import com.cg.loan.bean.Users;

import com.cg.loan.service.ILoanService;
import com.cg.loan.service.LoanService;

import javafx.scene.shape.Line;

public class Client {

	static Scanner sc= new Scanner(System.in);
	static Customer cust=new Customer();
	static Application app=new Application();
	static LoanProgramBean lb=new LoanProgramBean();
	static ILoanService service;
	static LocalDate today = LocalDate.now();
	
	public static void main(String[] args) throws LoanException {
		String opt;
		Users user;
		boolean v1;
		ILoanService service=new LoanService();
		int loginflag=0;
		String choice = null;
		String loanprogname = null;
		mainmenu:

		while(true)
		{
			
			System.out.println("\n******************************"
					+ "\nLOAN APPLICATION"
					+ "\n******************************"
					+ "\n\n[1] : Apply For Loan"
					+ "\n[2] : Login"
					+ "\n[3] : View Loan Application status."
					+ "\n[4] : Exit");
					
			opt=sc.next();
			
			switch(opt)
			{
		
			case "1":
				int optionInt;
				
				while(true)
				{
					
				try {
					
					ArrayList<LoanProgramBean> a=service.displayLoanProgram();
					
					System.out.println("\n***********************************");
					System.out.println("Select a loan program");
					System.out.println("***********************************\n");
					int i=1;
					if(a!=null)
					{
						System.out.format("%2s|%10s|%20s|%15s|%3s|%12s|%12s|%15s|%20s|\n","No.","Loan Name","Description","Type","Duration(Yrs.)","MinAmount","MaxAmount","RateofInterest","Proofs Required");
						line();
					}
					for(LoanProgramBean p:a)
					{
						System.out.println(i+" "+p);
						i++;
					}
					
					
						String option=sc.next();
					
					
						
					try
					{
						optionInt=Integer.parseInt(option);
						if(optionInt<1||optionInt>a.size())
						{
							System.out.println("Enter a valid choice !");
							continue;
						}
					}
					catch(NumberFormatException e)
					{
						System.out.println("Enter a valid choice !");
						continue;
					}
					
					
					
					
					
					System.out.println("The documents required are");
					System.out.println(a.get(optionInt-1).getProofsRequired());
					loanprogname=a.get(optionInt-1).getProgramName();
					System.out.println("Do you have all the documents? (Enter yes/no)");
					choice = sc.next();
					if (choice.equalsIgnoreCase("yes"))
					{
					
					System.out.println("Welcome! You can Proceed Further..");
					System.out.println("");
					getCustomerDetails();
					v1=service.isValid(cust);
					if(v1)
					{
						System.out.println("\n***********************************");
						System.out.println("Application Details Page");
						System.out.println("***********************************\n");
						
						getApplicationDetails(a,optionInt);
						double min = (a.get(optionInt-1).getMinLoanAmount());
						double max = (a.get(optionInt-1).getMaxLoanAmount());
						Boolean v2 = service.isValidApplication(app,min,max);
						if (v2)
						{
							
							app.setLoanProgram(loanprogname);
							Application t=service.addApplicationDetails(app);
							cust.setApplicationId(t.getAppId());
							Customer c=service.addCustomerDetails(cust);
							System.out.println("Customer successfully applied for the loan with application ID: "+app.getAppId());
							
						}
					}
					}
					else if (choice.equalsIgnoreCase("no"))
						{
						System.out.println("Sorry! You cannot proceed further..");
						continue mainmenu;
						}
				} catch (LoanException ex) {
					System.out.println(ex.getMessage());
				}

				
				break;
				}
		
			case "2":
				String opt1;
				while(true)
				{
				System.out.println("\n***********************************\n");
				System.out.println("Please Choose your Role :\n[1] : Loan Application Deparment\n[2] : Admin\n[3] : Back");
				System.out.println("\n***********************************");
				try {
				opt1=sc.next();
				user=new Users();
				service=new LoanService();
				switch(opt1) {
					case "1":
						LoginLad();
					
						break;
					case "2":
						user.setRole("admin");
						System.out.print("Enter User Name :");
						user.setName(sc.next());
						System.out.print("Enter Password :");
						user.setPassword(sc.next());
					try {
						boolean valid=service.validateAdmin(user);
						if(valid)
						{
							 loginflag=1;
							 Boolean var=true;
							adminmenu:
							while(var)
							{
								System.out.println("\n***********************************\n");
							System.out.println("Select an option:\n[1] : View Applications\n[2] : Manage Loan Programs\n[3] : Logout");
							System.out.println("\n***********************************");
							String opt2;
							opt2=sc.next();
							switch(opt2)
							{
							case "1": ArrayList<Application> ap=new ArrayList<>();
									ap=service.viewApplications();
									System.out.println("Loan Applications:");
									for(Application a:ap)
									{
										System.out.println(a);
									}
									break;
							case "2":
									
								
								while(true)
								{
									System.out.println("\n***********************************\n");
									System.out.println("Select the operation:\n[1] : Add\n[2] : Edit\n[3] : Delete\n[4] : View\n[5] : Back");
									System.out.println("\n***********************************");
							 		String opt3=sc.next();
							 		int k;
							 		switch(opt3)
							 		{
							 		case "1":k=0;
							 			lb=getLoanProgramDetails(k);
							 			valid=service.addLoanProgram(lb);
							 			if(valid)
							 			{
							 				System.out.println("Loan Program details inserted successfully!!");
							 			}
							 			break;
							 		case "2":
							 			System.out.println("\n***********************************\n");
							 			System.out.println("Enter type of Loan Program to be edited:");
										System.out.println("\n***********************************");
						 		 		String type=sc.next();
						 		 		LoanProgramBean lp=service.retrieveLoanProgram(type);
						 		 		System.out.println(lp);
						 		 		System.out.println("Enter New Loan Program Details:");
						 		 		k=1;
						 		 		LoanProgramBean g=getLoanProgramDetails(k);
						 		 		g.setType(type);
						 		 		valid=service.isValidLoanProgram(g);
							 			if(valid)
							 			{
							 				Boolean update=service.updateLoan(g);
							 				if(update)
							 				{
							 					System.out.println("Loan Program details updated successfully.");
							 				}
							 				else
							 				{
							 					System.out.println("Loan Program details updation failed !");
							 				}
							 			}
							 			break;
							 			
							 		case "3":System.out.println("Enter type of Loan Program to be deleted:");
							 		 	String LoanType=sc.next();
							 		 	boolean deleted=service.deleteLoanProgram(LoanType);
							 		 	if(deleted)
							 		 	{
							 		 		System.out.println("Loan program of type "+LoanType+" deleted successfully!");
							 		 	}
							 			break;
							 		case "4":ArrayList<LoanProgramBean> a=service.displayLoanProgram();
							 			System.out.println("\n***********************************\n");
							 			System.out.println("Loan Programs");
							 			System.out.println("\n***********************************");
							 			int i=1;
							 			for(LoanProgramBean p:a)
							 			{
							 				System.out.println(i+" "+p);
							 				i++;
							 			}
							 			break;
							 			
							 			
							 		case "5":
							 			continue adminmenu;
							 			
							 		default:
										System.out.println("Please select a valid Option. !");
							 			
							 		}
								}
							case "3":
								var=false;
								continue mainmenu;
							default:
								System.out.println("Please select a valid Option. !");
							}
						}
						}
					} catch (LoanException ex) {
						
						System.out.println(ex.getMessage());
					}
						break;
					case "3":
						continue mainmenu;
						
					default :
						System.out.println("Please enter a numeric value");
						break;
					}
				
					
				
				}
				catch(LoanException e) 
				{
				System.out.println("Please Enter a Numeric Value");
				}
				break;
					
					
			}
				break;
			case "3":
				int id;
				
				System.out.print("Enter Application ID: ");
				id=sc.nextInt();
				try {
					
					Application app=service.applicationStatus(id);
					System.out.println("\n***********************************\n");
					System.out.println("Application status for ID- "+id+" is :"+app.getStatus());
					if(app.getStatus().equals("Accepted"))
					{
						System.out.println("Date of interview is : "+app.getDateOfInterview());
					}
					
				}
				catch (LoanException e)
				{
					System.out.println(e.getMessage());
				}
				
				break;
			case "4":
				System.out.println("\nExiting....");
				System.exit(0);
				break;
				default:
					System.out.println("Please select a valid Option. !");
			
			}
		
	}
	}
	

	public static void getCustomerDetails()
	{
		
		System.out.println("Enter name:");
		cust.setCustomerName(sc.next());
		System.out.println("Enter date of birth (dd/mm/yyyy):");
		cust.setDateOfBirth(sc.next());
		System.out.println("Enter marital status: (married/single)");
		cust.setMaritalStatus(sc.next());
		System.out.println("Enter phone number:");
		cust.setPhoneNo(sc.next());
		System.out.println("Enter mobile number:");
		cust.setMobileNo(sc.next());
		System.out.println("Enter count of dependencies:");
		cust.setCountOfDependencies(sc.nextInt());
		System.out.println("Enter email id:");
		cust.setEmailId(sc.next());
	}
	
	public static void getApplicationDetails(List<LoanProgramBean> a,int option)
	{
		
		app.setLoanProgram(a.get(option-1).getProgramName());

		System.out.println("Enter Loan Amount (Min: "+a.get(option-1).getMinLoanAmount()+" ,"+"Max: "+a.get(option-1).getMaxLoanAmount()+"):");
		app.setAmountOfLoan(sc.nextInt());
		System.out.println("Enter Property Address: ");
		app.setAddressOfProperty(sc.next());
		System.out.println("Enter Annual family Income:");
		app.setAnnualFamilyIncome(sc.nextInt());

		System.out.println("Enter Guarentee Cover:");
		app.setGuarenteeCover(sc.next());
		System.out.println("Enter Market Value Of Gurarntee:");
		app.setMarketValueOfGurarntee(sc.next());
		
		
	}
	
	public static LoanProgramBean getLoanProgramDetails(int k)
	{
		LoanProgramBean loan=new LoanProgramBean();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Program Name:");
		loan.setProgramName(sc.next());
		System.out.println("Enter the description:");
		sc.nextLine();
		loan.setDescription(sc.nextLine());
		if(k!=1)
		{
		System.out.println("Enter program type:");
		loan.setType(sc.next());
		}
		System.out.println("Enter duration of years:");
		loan.setDurationOfYears(sc.nextInt());
		System.out.println("Enter Minimum Loan amount:");
		loan.setMinLoanAmount(sc.nextDouble());
		System.out.println("Enter Maximum Loan amount:");
		loan.setMaxLoanAmount(sc.nextDouble());
		System.out.println("Enter Rate of Interest:");
		loan.setRateOfInterest(sc.nextDouble());
		System.out.println("Enter Proofs required:");
		loan.setProofsRequired(sc.next());
		return loan;
	}

	



	public static void LAD(String type) throws LoanException {
		sc= new Scanner(System.in);
		app=new Application();
		Application uapp;
		List<Application> loanlist=new ArrayList<>();
		//app.setLoanProgram(type);
		loanlist=service.getLoanDetails(type);
		if(!loanlist.isEmpty()) 
		{
			System.out.println("\n***********************************");
			System.out.println("APPLICATION FOR "+type.toUpperCase());
			System.out.println("***********************************\n");
			for(Application a:loanlist) 
			{
				System.out.println(a);
			}
			System.out.println("\nSelect ID to update the status of loan Application");
			int id = 0;
			try
			{
				id=sc.nextInt();
			}
			catch(InputMismatchException e)
			{
				System.out.println("Enter a valid number ");
				LAD(type);
			}
			boolean x=false;
			for(Application a:loanlist) 
			{
				if(a.getAppId()==id) 
				x=true;
			}
			if(x) {
				System.out.println("Choose an Option to change the status"
						+ "\n1)Accepted\n2)Rejected\n3)Approved");
				int opt4=sc.nextInt();
				switch(opt4) {
				case 1:
					System.out.println("Enter Interview Date :(DD/MM/YYYY)");
					service.updateIdate(id,sc.next());
					uapp=service.updateStatus(id,"Accepted");
					System.out.println("Loan Status Updated Sucessfully\n"+uapp);
					break;
				case 2:
					uapp=service.updateStatus(id,"Rejected");
					System.out.println("Loan Status Updated Sucessfully\n"+uapp);
					break;
				case 3:
					uapp=service.updateStatus(id,"Approved");
					System.out.println("Loan Status Updated Sucessfully\n"+uapp);
					service.AddApprovedDetails(id);
					break;
				
				default :
					System.out.println("Please choose a numeric value from 1 t0 3");
					break;}
			}
			else {
				System.err.println("Entered an Invalid Id please choose correct ID");
				LAD(type);
				
		
			}
			
			
		}
		else System.out.println("No Records Found");
	}
	
	public static void LoginLad() throws LoanException
	{
		Users user=new Users();
		user.setRole("lad");
		service=new LoanService();
		System.out.println("Enter User Name :");
		user.setName(sc.next());
		System.out.println("Enter Password :");
		user.setPassword(sc.next());
		boolean valid=service.validateUser(user);
		if(valid) {
			String opt2;
			boolean val=true;
			while(val) {
			System.out.println("Choose type of Loan Program");
			System.out.println("\n1)Loan For Purchase"
					+ "\n2)Loan For Construction"
					+ "\n3)Loan For Extension"
					+ "\n4)Loan For Renovation"
					+ "\n5)get approved details"
					+"\n6)Logout");
			try {
			opt2=sc.next();
			
			switch(opt2) {
			case "1":
					LAD("Purchase");
				break;	
			case "2":
					LAD("Construction");
				break;
			case "3":
					LAD("Extension");
				break;
			case "4":
				LAD("Renovation");
				break;
			case "5":
				ArrayList<ApprovedLoans> list=new ArrayList<>();
				list=service.getApprovedLoanDetails();
				if(!list.isEmpty()) {
					for(ApprovedLoans a:list) 
					{
						System.out.println(a+"\n");
					}
				}
				break;
			case "6":
				val=false;
				String[] a = null;
				main(a);
				break;
				default:
					System.out.println("Please choose from 1 to 6");
					break;
			}
			}
			catch(LoanException e) {
				System.out.println("Enter a numeric value !");
			}
		}
			}
		else {
			System.out.println("Invalid Credentials Please Try Again");
			LoginLad();
		}
	}
	
	
	
	
	public static void line()
	{
		System.out.println("______________________________________________________________________________________________________________________________________________");
	}
}

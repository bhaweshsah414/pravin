package com.cg.loan.dao;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.Users;
import com.cg.loan.util.DBUtil;

import static org.hamcrest.CoreMatchers.nullValue;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.loan.bean.LoanProgramBean;

import com.cg.loan.exception.LoanException;


public class LoanDao implements ILoanDao{
	 Connection con=DBUtil.getConnection();
	 PreparedStatement ps = null;
	 private static Logger logger=Logger.getRootLogger();
	 private PreparedStatement preparedStatement;
	
	 
	@Override
	public ArrayList<LoanProgramBean> displayLoanProgram() throws LoanException {
		
		ResultSet rs=null;
		ArrayList<LoanProgramBean> al=new ArrayList<LoanProgramBean>();
		
		PropertyConfigurator.configure("resources//log4j.properties");
		try {
			ps=con.prepareStatement(QueryMapper.SELECT_QUERY);
			
			rs= ps.executeQuery();
			
			while(rs.next())
				{
					LoanProgramBean l=new LoanProgramBean();
					l.setProgramName(rs.getString(1));
					l.setDescription(rs.getString(2));
					l.setType(rs.getString(3));
					l.setDurationOfYears(rs.getInt(4));
					l.setMinLoanAmount(rs.getDouble(5));
					l.setMaxLoanAmount(rs.getDouble(6));
					l.setRateOfInterest(rs.getDouble(7));
					l.setProofsRequired(rs.getString(8));
					al.add(l);
				}
			
		} catch (SQLException exe) {
			logger.error("Fetching of Loan Programs unsuccessful!"+exe);
			throw new LoanException("Fetching of Loan Programs unsuccessful!");
		}
		return al;
	}

	@Override
	public boolean validateAdmin(Users user) throws LoanException {
		
		try {
			
			ps = con.prepareStatement(QueryMapper.VALIDATE_QUERY);
			ps.setString(1, user.getName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ResultSet rs=ps.executeQuery();
			if(rs.next()) 
			{
				return true;
			}
		}
		catch(Exception ex){
			System.err.println(ex.getMessage());
		}
		return false;
	}


	
	
	

	@Override
	public boolean validateUser(Users user) {
	
		try {
			
			preparedStatement = con.prepareStatement(QueryMapper.VALIDATE_QUERY);
			preparedStatement.setString(1, user.getName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getRole());
			ResultSet rs=preparedStatement.executeQuery();

			if(rs.next()) 
			{
				return true;
			}
		}

		catch(Exception ex){
			System.err.println(ex.getMessage());

		}
		return false;
	}

	@Override
	public ArrayList<Application> viewApplications() throws LoanException {
		ResultSet rs=null;
		ArrayList<Application> t=new ArrayList<>();
		
		try {
			ps=con.prepareStatement(QueryMapper.VIEW_APPLICATIONS_QUERY);
			rs= ps.executeQuery();
						
			while(rs.next())
			{
				Application a=new Application();
				a.setAppId(rs.getInt(1));
				a.setAppDate(rs.getDate(2));
				a.setLoanProgram(rs.getString(3));
				a.setAmountOfLoan(rs.getInt(4));
				a.setAddressOfProperty(rs.getString(5));
				a.setAnnualFamilyIncome(rs.getInt(6));
				a.setDocumentsProofAvailable(rs.getString(7));
				a.setGuarenteeCover(rs.getString(8));
				a.setMarketValueOfGurarntee(rs.getString(9));
				a.setStatus(rs.getString(10));
				a.setDateOfInterview(rs.getDate(11).toString());
				t.add(a);
			}
			
		} catch (SQLException er) {
			logger.error("Fetching of Loan Applications unsuccessful! SQLException: "+er);
			throw new LoanException("Error with Database ");
		}
		return t;
	}

	@Override
	public boolean deleteLoanProgram(String LoanType) throws LoanException {
		
		try {
			
			
			ps=con.prepareStatement(QueryMapper.LOANDETAILS_QUERY);
			ps.setString(1, LoanType);
			ResultSet flag=ps.executeQuery();
			if(flag.next())
			{
				throw new LoanException("This Type of Loan programs has Applicants !");
			}
			ps=con.prepareStatement(QueryMapper.DELETE_LOAN_PROGRAM);
			ps.setString(1, LoanType);
			int k=ps.executeUpdate();
			if(k==1)
			{
				return true;
			}
			else
			{
				return false;
			}
			
		} catch (SQLException e) {
			logger.error("Deletion of LoanProgram Failed ! SQLException: "+e);
			throw new LoanException("Enter a valid type of Loan Program!");
		}
	}

	@Override
	public boolean addLoanProgram(LoanProgramBean loan) throws LoanException {
		
		try {
			ps=con.prepareStatement(QueryMapper.FIND_LOAN_PROGRAM);
			ps.setString(1, loan.getType());
			ResultSet rs=null;
			rs=ps.executeQuery();
			
			if(!rs.next())
			{
				PreparedStatement p=con.prepareStatement(QueryMapper.INSERT_LOAN_PROGRAM);
				p.setString(1, loan.getProgramName());
				p.setString(2, loan.getDescription());
				p.setString(3, loan.getType());
				p.setInt(4, loan.getDurationOfYears());
				p.setDouble(5, loan.getMinLoanAmount());
				p.setDouble(6, loan.getMaxLoanAmount());
				p.setDouble(7, loan.getRateOfInterest());
				p.setString(8, loan.getProofsRequired());
				
				int r=p.executeUpdate();
				
				if(r==2) {
					logger.error("Insertion failed");
				}
				else {
					logger.info(r+" rows inserted");
					logger.info("Loan Program details added successfully");
					return true;
				}
			}
			else
			{
				throw new LoanException("Loan Program of this type already exists!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public LoanProgramBean retrieveLoanProgram(String type) throws LoanException {
		LoanProgramBean l=new LoanProgramBean();
		try {
			ps=con.prepareStatement(QueryMapper.FIND_LOAN_PROGRAM);
			ps.setString(1, type);
			ResultSet rs=null;
			rs=ps.executeQuery();
			
			if(rs.next())
			{
				l.setProgramName(rs.getString(1));
				l.setDescription(rs.getString(2));
				l.setType(rs.getString(3));
				l.setDurationOfYears(rs.getInt(4));
				l.setMinLoanAmount(rs.getDouble(5));
				l.setMaxLoanAmount(rs.getDouble(6));
				l.setRateOfInterest(rs.getDouble(7));
				l.setProofsRequired(rs.getString(8));
			}
			else
			{
				throw new LoanException("No loan program of this type exists!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}

	@Override
	public Boolean updateLoan(LoanProgramBean loan) throws LoanException {
		
		try {
			ps=con.prepareStatement(QueryMapper.UPDATE_LOAN_PROGRAM);
			
			ps.setString(1, loan.getProgramName());
			ps.setString(2, loan.getDescription());
			ps.setDouble(3, loan.getDurationOfYears());
			ps.setDouble(4, loan.getMinLoanAmount());
			ps.setDouble(5, loan.getMaxLoanAmount());
			ps.setDouble(6, loan.getRateOfInterest());
			ps.setString(7, loan.getProofsRequired());
			ps.setString(8, loan.getType());
			
			int r=ps.executeUpdate();
						
			if(r==0) {
				System.out.println("Update Failed!");
			}
			else {
				
				
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}


	@Override
	public List<Application> getLoanDetails(String loanProgram) {
		ArrayList<Application> loanList=new ArrayList<>();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps = con.prepareStatement(QueryMapper.LOANDETAILS_QUERY);
			ps.setString(1,loanProgram);
			rs=ps.executeQuery();
		
			while(rs.next()) 
			{
			
		
			Application app=new Application();
			
			
			app.setAppId(rs.getInt(1));
			app.setAppDate(rs.getDate(2));
			app.setLoanProgram(rs.getString(3));
			app.setAmountOfLoan(rs.getInt(4));
			app.setAddressOfProperty(rs.getString(5));
			app.setAnnualFamilyIncome(rs.getInt(6));
			app.setDocumentsProofAvailable(rs.getString(7));
			app.setGuarenteeCover(rs.getString(8));
			app.setMarketValueOfGurarntee(rs.getString(9));
			app.setStatus(rs.getString(10));
			app.setDateOfInterview(rs.getDate(11).toString());
			
			loanList.add(app);
			
			
			}
		}
		
		catch (Exception e) 
		{
			
		}
		return loanList;
	}
	
	
//	@Override
//	public int addClientDetails(Application app) throws LoanException {
//		
//		con=DBUtil.getConnection();
//		
//		if(con == null) {
//			logger.fatal("Connection failed");
//			throw new LoanException("DataBase connection failed");
//			
//			}
//			int cid = 0;
//			
//			try {	
//			
//				con.prepareStatement(QueryMapper.INSERT_QUERY);	
//			
//				System.out.println("Check control 1");
//				
//					
//				
//
//
//				
//				
//			} catch (SQLException e) {
//			
//				logger.error("exception occured", e);
//				throw new LoanException("Wrong Info");
//				
//			}
//			finally {
//				if(con!= null)
//					try {
//						con.close();
//						} 
//				catch (SQLException e) {
//					logger.error("Please Check Connection", e);
//					throw new LoanException("Connection Problem Occured");
//					}
//				}
//			return cid;
//	}
//	
	
	
	

	@Override
	public Application updateStatus(int id,String status) {
	//	System.out.println("Entered in doa update\n");
		Application app=new Application();
		try {
			preparedStatement = con.prepareStatement(QueryMapper.LOANSTATUS_QUERY);
			preparedStatement.setString(1,status);
			preparedStatement.setInt(2,id);
			int update=preparedStatement.executeUpdate();
			//System.out.println(update);
			//System.out.println(id+status);
			if(update==1) 
			{
				preparedStatement=con.prepareStatement(QueryMapper.GETDETAILS_QUERY);
				preparedStatement.setInt(1,id);
				ResultSet rs=preparedStatement.executeQuery();
				if(rs.next()) 
				{
				app.setAppId(rs.getInt(1));
				app.setAppDate(rs.getDate(2));
				app.setLoanProgram(rs.getString(3));
				app.setAmountOfLoan(rs.getInt(4));
				app.setAddressOfProperty(rs.getString(5));
				app.setAnnualFamilyIncome(rs.getInt(6));
				app.setDocumentsProofAvailable(rs.getString(7));
				app.setGuarenteeCover(rs.getString(8));
				app.setMarketValueOfGurarntee(rs.getString(9));
				app.setStatus(rs.getString(10));
				app.setDateOfInterview(rs.getDate(11).toString());
				return app;
			}
				}
		
	}catch (Exception e) {
		// TODO: handle exception
	}
		return app;
		
 }

	@Override
	public Application applicationStatus(int id) throws LoanException {
		Application app= new Application();
		con=DBUtil.getConnection();
		if(con == null) {
			logger.fatal("Connection failed");
			throw new LoanException("DataBase connection failed");
			}
			try {	
			
				ps=con.prepareStatement(QueryMapper.APPLICATION_STATUS_DATE);	
				ps.setInt(1, id);
				ResultSet rs=ps.executeQuery();
				if(!rs.next())
				{
					throw new LoanException("Application  ID does not exist !");
				}
				
				else
				{
					
					app.setStatus(rs.getString(1));
					app.setDateOfInterview(rs.getDate(2).toString());
				
					return app;
				}
					
			} catch (SQLException e) {
			
				logger.error("exception occured", e);
				throw new LoanException("SQL Exception"+e);
				
			}
			finally {
				if(con!= null)
					try {
						con.close();
						} 
				catch (SQLException e) {
					logger.error("Please Check Connection", e);
					throw new LoanException("Connection Problem Occured");
					}
				}
		
	
	}
	
	
	
	
	@Override
	public Application addApplicationDetails(Application app) throws LoanException {
		
		con=DBUtil.getConnection();
		
		if(con == null) {
			logger.fatal("Connection failed");
			throw new LoanException("DataBase connection failed");
			
			}
			int cid = 0;
			
			try {	
				
				ps=con.prepareStatement(QueryMapper.INSERT_APPLICATION_QUERY);	
				ps.setString(1, app.getLoanProgram());
				ps.setInt(2, app.getAmountOfLoan());
				ps.setString(3, app.getAddressOfProperty());
				ps.setInt(4, app.getAnnualFamilyIncome());
				ps.setString(5, app.getDocumentsProofAvailable());
				ps.setString(6, app.getGuarenteeCover());
				ps.setString(7, app.getMarketValueOfGurarntee());
				ps.setString(8, app.getStatus());
				
				int r=ps.executeUpdate();
				if(r==0) {
					System.out.println("Insertion Failed!");
				}
				else {
					
					//System.out.println("Application details added successfully");
					PreparedStatement p=con.prepareStatement(QueryMapper.APPID_QUERY);
					ResultSet rs=p.executeQuery();
					if(rs.next())
					{
						//app.setAppId(rs.getInt(1));
						//PreparedStatement k=con.prepareStatement(QueryMapper.INTERVIEWDATE_QUERY);
						//k.setInt(1, app.getAppId());
						//ResultSet l=k.executeQuery();
						//if(l.next())
						//{
						//	app.setDateOfInterview(l.getDate(2).toString());
						//	Date d=l.getDate(1);
						//	app.setAppDate(l.getDate(1));
						//}
						
						
						
						app.setAppId(rs.getInt(1));
					}
					return app;
				}
				
			} catch (SQLException e) {
			
				logger.error("exception occured", e);
				throw new LoanException("Wrong Info"+e);////
				
			}
			finally {
				if(con!= null)
					try {
						con.close();
						} 
				catch (SQLException e) {
					logger.error("Please Check Connection", e);
					throw new LoanException("Connection Problem Occured");
					}
				}
			return app;
	}
	
	
	@Override
	public void updateIdate(int id, String date) {
		try {
			preparedStatement = con.prepareStatement(QueryMapper.UPDATEIDATE_QUERY);
			
			DateTimeFormatter d=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate dt=LocalDate.parse(date, d);
			Date date1=Date.valueOf(dt);
			preparedStatement.setDate(1,date1);
			preparedStatement.setInt(2,id);
			preparedStatement.executeUpdate();
			
			}
		catch(SQLException e)
		{
			
		}
		
	}
	
	
	
	
	@Override
	public Customer addCustomerDetails(Customer cust) throws LoanException {
		con=DBUtil.getConnection();
		
		if(con == null) {
			logger.fatal("Connection failed");
			throw new LoanException("DataBase connection failed");
			
			}
			int cid = 0;
			try {
				
				
				DateTimeFormatter d=DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate date=LocalDate.parse(cust.getDateOfBirth(), d);
				Date dt=Date.valueOf(date);
				
				
				ps=con.prepareStatement(QueryMapper.INSERT_CUSTOMER_DETAILS);
				ps.setInt(1, cust.getApplicationId());
				ps.setString(2, cust.getCustomerName());
				ps.setDate(3, dt);
				ps.setString(4, cust.getMaritalStatus());
				ps.setDouble(5, Double.parseDouble(cust.getPhoneNo()));
				ps.setDouble(6, Double.parseDouble(cust.getMobileNo()));
				ps.setInt(7, cust.getCountOfDependencies());
				ps.setString(8, cust.getEmailId());
				int r=ps.executeUpdate();
				if(r==0) {
					System.out.println("Insertion Failed!");
				}
				
			} catch (SQLException e) {
				logger.error("exception occured", e);
				throw new LoanException("SQL Exception"+e.getMessage());
			}
			finally {
				if(con!= null)
					try {
						con.close();
						} 
				catch (SQLException e) {
					logger.error("Please Check Connection", e);
					throw new LoanException("Connection Problem Occured");
					}
				}
			return cust;
	}
	
	@Override
	public ArrayList<ApprovedLoans> getApprovedLoanDetails()
	{
		ArrayList<ApprovedLoans> list=new ArrayList<>();
		ApprovedLoans app;
		try {
			preparedStatement = con.prepareStatement(QueryMapper.GETAPPROVED_QUERY);
	
			ResultSet rs=preparedStatement.executeQuery();
			
			while(rs.next()) {
				
			app=new ApprovedLoans();
			
			app.setAppID(rs.getInt(1));
			app.setCustomerName(rs.getString(2));
			app.setLoanAmountGranted(rs.getInt(3));
			app.setMonthlyInstallment(rs.getInt(4));
			app.setYears_timeperiod(rs.getInt(5));
			app.setDown_Payment(rs.getInt(6));
			app.setRate_of_interest(rs.getInt(7));
			app.setTotal_Amount_Payable(rs.getInt(8));
			
			list.add(app);
			
			}
			return list;
		}
		catch (Exception e) {
			
		}
		return list;
	}

	@Override
	public void AddApprovedDetails(int id) {
		try {
			preparedStatement = con.prepareStatement(QueryMapper.ADDAPPROVED_QUERY);
			preparedStatement.setInt(1,id);
			ResultSet rs=preparedStatement.executeQuery();	
			if(rs.next()) 
			{
				int value=rs.getInt(1);
				preparedStatement=con.prepareStatement(QueryMapper.INSERTAPPROVED_QUERY);
				preparedStatement.setInt(1,id);
				preparedStatement.setString(2,rs.getString(2));
				preparedStatement.setInt(3,value);
				preparedStatement.setInt(4,value/24);
				preparedStatement.setInt(5,2);
				preparedStatement.setLong(6,Math.round(value*0.1));
				preparedStatement.setInt(7,2);
				preparedStatement.setLong(8,Math.round(value*(1+0.2*2)));
				preparedStatement.executeQuery();
					
			}
		}
		catch (Exception e) {
			logger.error("Error Occured while Approving Status");
		}
		
	}
	
	
	}

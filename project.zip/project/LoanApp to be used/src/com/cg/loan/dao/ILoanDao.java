package com.cg.loan.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanProgramBean;
import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;

public interface ILoanDao {


	public ArrayList<LoanProgramBean> displayLoanProgram() throws LoanException;
	public boolean validateAdmin(Users user) throws LoanException;
	public ArrayList<Application> viewApplications() throws LoanException;
	public boolean deleteLoanProgram(String LoanType) throws LoanException;
	public boolean addLoanProgram(LoanProgramBean loan) throws LoanException;
	public LoanProgramBean retrieveLoanProgram(String type) throws LoanException;
	public Boolean updateLoan(LoanProgramBean loan)  throws LoanException;
	public boolean validateUser(Users user);
	public List<Application> getLoanDetails(String loanProgram);
	public Application updateStatus(int id,String status);
	//int addClientDetails(Application app) throws LoanException;
	public Application applicationStatus(int id) throws LoanException;
	public Customer addCustomerDetails(Customer cust) throws LoanException;
	public Application addApplicationDetails(Application app) throws LoanException;
	
	public ArrayList<ApprovedLoans> getApprovedLoanDetails();
	public void AddApprovedDetails(int id);
	
	public void updateIdate(int id, String date);
}

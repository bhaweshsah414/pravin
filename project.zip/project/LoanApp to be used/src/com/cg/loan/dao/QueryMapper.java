package com.cg.loan.dao;

public interface QueryMapper {
	public static final String VALIDATE_QUERY="SELECT login_id,password,role FROM users WHERE login_id=? AND password=? AND role=?";
	public static final String LOANDETAILS_QUERY="SELECT * FROM loanapplication where loan_program=?";
	public static final String LOANSTATUS_QUERY="UPDATE loanapplication SET status=? WHERE application_id=?";
	public static final String GETDETAILS_QUERY="select * from loanapplication where application_id=?";
	public static final String SELECT_QUERY="SELECT * FROM LoanProgramsOffered" ;
	public static final String VIEW_APPLICATIONS_QUERY="SELECT * FROM loanapplication" ;
	public static final String DELETE_LOAN_PROGRAM="DELETE FROM LoanProgramsOffered WHERE type=?";
	public static final String FIND_LOAN_PROGRAM="SELECT * FROM LoanProgramsOffered WHERE type=?";
	public static final String INSERT_LOAN_PROGRAM="INSERT INTO LoanProgramsOffered VALUES(?,?,?,?,?,?,?,?)";
	public static final String UPDATE_LOAN_PROGRAM="UPDATE LoanProgramsOffered SET program_name=?,description=?,durationinyears=?,minloanamount=?,maxloanamount=?,rateofinterest=?,proofs_required=? WHERE type=?";
	public static final String APPLICATION_STATUS_DATE=" SELECT status,dateofinterview FROM loanapplication WHERE application_id=?";
	public static final String INSERT_APPLICATION_QUERY="INSERT INTO LoanApplication VALUES (CUSTID_SEQ.nextval,sysdate,?,?,?,?,?,?,?,?,sysdate)";
	public static final String APPID_QUERY="SELECT CUSTID_SEQ.currval from dual";
	public static final String INTERVIEWDATE_QUERY="SELECT application_date,dateofinterview from loanapplication where application_id=?";
	public static final String INSERT_CUSTOMER_DETAILS="INSERT INTO customer_details VALUES (?,?,?,?,?,?,?,?)";
	public static final String ADDAPPROVED_QUERY="select a.amountofloan,c.applicant_name from loanapplication a,customer_details c where a.application_id=c.application_id and a.application_id=?";
	public static final String INSERTAPPROVED_QUERY="insert into approvedloans values(?,?,?,?,?,?,?,?)";
	public static final String GETAPPROVED_QUERY="select * from approvedloans";
	public static final String UPDATEIDATE_QUERY = "UPDATE loanapplication SET dateofinterview=? where application_id=?";


}



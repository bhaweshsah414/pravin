package com.cg.loan.bean;

public class ApprovedLoans {
	
	private int AppID; 
	private String CustomerName; 
	private int LoanAmountGranted; 
	private int MonthlyInstallment; 
	private int Years_timeperiod; 
	private int Down_Payment;
	private int Rate_of_interest;
	private int Total_Amount_Payable;
	public int getAppID() {
		return AppID;
	}
	public void setAppID(int appID) {
		AppID = appID;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public int getLoanAmountGranted() {
		return LoanAmountGranted;
	}
	public void setLoanAmountGranted(int loanAmountGranted) {
		LoanAmountGranted = loanAmountGranted;
	}
	public int getMonthlyInstallment() {
		return MonthlyInstallment;
	}
	public void setMonthlyInstallment(int monthlyInstallment) {
		MonthlyInstallment = monthlyInstallment;
	}
	public int getYears_timeperiod() {
		return Years_timeperiod;
	}
	public void setYears_timeperiod(int years_timeperiod) {
		Years_timeperiod = years_timeperiod;
	}
	public int getDown_Payment() {
		return Down_Payment;
	}
	public void setDown_Payment(int down_Payment) {
		Down_Payment = down_Payment;
	}
	public int getRate_of_interest() {
		return Rate_of_interest;
	}
	public void setRate_of_interest(int rate_of_interest) {
		Rate_of_interest = rate_of_interest;
	}
	public int getTotal_Amount_Payable() {
		return Total_Amount_Payable;
	}
	public void setTotal_Amount_Payable(int total_Amount_Payable) {
		Total_Amount_Payable = total_Amount_Payable;
	}
	@Override
	public String toString() {
		return "ApprovedLoans [AppID=" + AppID + ", CustomerName=" + CustomerName + ", LoanAmountGranted="
				+ LoanAmountGranted + ", MonthlyInstallment=" + MonthlyInstallment + ", Years_timeperiod="
				+ Years_timeperiod + ", Down_Payment=" + Down_Payment + ", Rate_of_interest=" + Rate_of_interest
				+ ", Total_Amount_Payable=" + Total_Amount_Payable + "]";
	}
	
	
	
}
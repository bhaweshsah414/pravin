package com.cg.loan.exception;

public class LoanException extends Exception{

	
	

	public LoanException(String msg)
	{
		
		System.err.println(msg);
	}

	

}

package com.cg.loan.test;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.Customer;
import com.cg.loan.exception.LoanException;
import com.cg.loan.service.ILoanService;
import com.cg.loan.service.LoanService;

import junit.framework.Assert;

public class LoanServiceImplTest {

	static Customer c=new Customer();
	static Customer cust=new Customer();
	static Application app=new Application();
	@Before
	public void beforeValidateCustTest() throws Exception{
		
		c.setCustomerName("karuna");
		c.setDateOfBirth("24/12/1996");
		c.setMaritalStatus("single");
		c.setPhoneNo("87954621");
		c.setMobileNo("8795462130");
		c.setCountOfDependencies(2);
		c.setEmailId("karuna@gmail.com");
		
		cust.setCustomerName("karuna");
		cust.setDateOfBirth("24/12/1996");
		cust.setMaritalStatus("single");
		cust.setPhoneNo("87954621");
		cust.setMobileNo("8795462130");
		cust.setCountOfDependencies(2);
		cust.setEmailId("karunagmail.com");
	}
	
	@Test
	public void validateCustTest() {
		ILoanService service=new LoanService();
		try {
			boolean v=service.isValid(c);
			Assert.assertEquals(v, true);
		} catch (LoanException e) {
			e.printStackTrace();
		}
		
		try {
			boolean v=service.isValid(cust);
			Assert.assertEquals(v, false);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@After
	public void afterValidateCustTest() throws Exception{
		c=null;
	}
}

package com.cg.loan.test;

import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.Customer;
import com.cg.loan.dao.ILoanDao;
import com.cg.loan.dao.LoanDao;
import com.cg.loan.exception.LoanException;
import com.cg.loan.util.DBUtil;

import junit.framework.Assert;

public class LoanDaoTest {

	private ILoanDao dao;
	private Application app=new Application();
	private Customer cust=new Customer();
	
	@Before
	public void beforeTest(){
		dao=new LoanDao();
		app.setLoanProgram("Purchase");
		app.setAmountOfLoan(2200);
		app.setAddressOfProperty("Hyderabad");
		app.setAnnualFamilyIncome(895622);
		app.setDocumentsProofAvailable("Aadhar");
		app.setGuarenteeCover("Same");
		app.setMarketValueOfGurarntee("78451");
		app.setStatus("Applied");
		
		
	}
	
	@Test
	public void addApplicationDetailsTest() {
		try {
			
			Application a=dao.addApplicationDetails(app);
			boolean b = false;
			if(a.getAppId()!=0)
			{
				b=true;
			}
			Assert.assertEquals(true, b);
		} catch (LoanException e) {
			
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void addCustomerDetails() {
		try {
			cust.setApplicationId(app.getAppId());
			cust.setCustomerName("Karuna");
			cust.setDateOfBirth("24/12/1996");
			cust.setMaritalStatus("single");
			cust.setPhoneNo("87954621");
			cust.setMobileNo("8795462130");
			cust.setCountOfDependencies(2);
			cust.setEmailId("karuna@gmail.com");
			Customer c=dao.addCustomerDetails(cust);
			boolean b = false;
			if(c.getApplicationId()!=0)
			{
				b=true;
			}
			Assert.assertEquals(true, b);
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@After
	public void tearDown() throws Exception {
		Connection con = DBUtil.getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM loanapplication WHERE application_id=?");
		st.setInt(1,app.getAppId());
		st.executeUpdate();
		PreparedStatement st1 = con.prepareStatement("DELETE FROM customer_details WHERE application_id=?");
		st1.setInt(1,cust.getApplicationId());
		st1.executeUpdate();
		if(con!=null && !con.isClosed())
			con.close();
	}
}

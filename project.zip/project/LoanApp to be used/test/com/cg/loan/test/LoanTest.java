package com.cg.loan.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.loan.bean.Users;
import com.cg.loan.dao.ILoanDao;
import com.cg.loan.dao.LoanDao;
import com.cg.loan.exception.LoanException;
import com.cg.loan.util.DBUtil;

import junit.framework.Assert;

public class LoanTest {
	
	private static Connection con;

	private static PreparedStatement st;

	@Before
	public void beforeTest() throws Exception{
		con = DBUtil.getConnection();
		st = con.prepareStatement("INSERT INTO users values(?,?,?)");
		st.setString(1,"user");
		st.setString(2, "p@ssw0rd");
		st.setString(3, "admin");
		st.executeQuery();
		if(con!=null && !con.isClosed())
			con.close();
	}
	
	@Test
	public void testAdd() {
		
		ILoanDao h=new LoanDao();
		Users k=new Users();
		k.setName("user");
		k.setPassword("p@ssw0rd");
		k.setRole("admin");
		boolean t;
		try {
			t=h.validateAdmin(k);
			Assert.assertEquals(t, true);
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	@After
	public void tearDown() throws Exception {
		Connection con = DBUtil.getConnection();
		PreparedStatement st = con.prepareStatement("DELETE FROM Users WHERE login_id=?");
		st.setString(1,"user");
		st.executeUpdate();
		if(con!=null && !con.isClosed())
			con.close();
	}
	
}

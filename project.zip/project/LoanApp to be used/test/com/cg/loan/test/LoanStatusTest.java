package com.cg.loan.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.loan.bean.Application;
import com.cg.loan.bean.Users;
import com.cg.loan.dao.ILoanDao;
import com.cg.loan.dao.LoanDao;
import com.cg.loan.exception.LoanException;
import com.cg.loan.util.DBUtil;

import junit.framework.Assert;


public class LoanStatusTest 
{
	
	private static Connection con;

	private static PreparedStatement st2;
	
	
	@Before
	public void beforeClassMethod() throws LoanException
	{
		 con= DBUtil.getConnection();
		 
		try {
			
			st2 = con.prepareStatement("INSERT INTO loanapplication values(100,sysdate,'',00,'',00,'','',00,'Applied',sysdate)");
			st2.executeUpdate();
			if(con!=null && !con.isClosed())
				con.close();
		
		} catch (SQLException e) {
			System.out.println(e);
		}
		
	}
	
	@Test
	public void statTest() throws LoanException
	{
		ILoanDao h=new LoanDao();
		Application app=h.applicationStatus(100);
		System.out.println(app.getStatus());
		Assert.assertEquals(app.getStatus(), "Applied");
		
	}
	
	@After
	public void tearDown() throws SQLException
	{
		 con = DBUtil.getConnection();
		 st2 = con.prepareStatement("DELETE FROM loanapplication WHERE application_id=?");
		st2.setInt(1,100);
		st2.executeUpdate();
		if(con!=null && !con.isClosed())
			con.close();
	}
	
}

package com.capstore.admin.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class CartDTO{

	@Id
	@Column(name="promocode")
	private String promoCode;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="productprice")
	private int productPrice;
	
	@OneToMany(fetch = FetchType.LAZY)
	private List<ProductDTO> product;

	
	public CartDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public List<ProductDTO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDTO> product) {
		this.product = product;
	}
	
	
	}

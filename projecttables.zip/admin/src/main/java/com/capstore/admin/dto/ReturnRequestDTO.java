package com.capstore.admin.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="returnrequest")
public class ReturnRequestDTO {

	@Id
	@Column(name="refundAmount")
	private int refundAmount;
	@Column(name="returnStatus")
	private String returnStatus;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private CustomerDTO customer;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private ProductDTO product;
	
	@OneToOne(fetch = FetchType.LAZY)
	private OrderDTO order;
	
	public int getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(int refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public OrderDTO getOrder() {
		return order;
	}
	public void setOrder(OrderDTO order) {
		this.order = order;
	}
	
	
}

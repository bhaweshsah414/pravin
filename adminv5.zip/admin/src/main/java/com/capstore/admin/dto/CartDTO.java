package com.capstore.admin.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
//import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
//import javax.persistence.JoinColumn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="cart")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class CartDTO{

	@Id
	@Column(name="customerid")
	private int customerid;
	@Column(name="productid")
	private int productid;
	@Column(name="promocode")
	private String promoCode;
	@Column(name="productquantity")
	private int productQuantity;
	@Column(name="productprice")
	private int productprice;
	@Column(name="softdelete")
	private String softdelete;
	
	
	@OneToMany(mappedBy="carts", fetch = FetchType.LAZY)
	private List<ProductDTO> product;
	

	
	public CartDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getProductPrice() {
		return productprice;
	}
	public void setProductPrice(int productPrice) {
		this.productprice = productPrice;
	}
	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	public List<ProductDTO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductDTO> product) {
		this.product = product;
	}
	
	
	}

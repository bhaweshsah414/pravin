package com.capstore.admin.dto;

public enum ReturnStatus 
{
	APPLIED,
	APPROVED,
	REJECTED

}

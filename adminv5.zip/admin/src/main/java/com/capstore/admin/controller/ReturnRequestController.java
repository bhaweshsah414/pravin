package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.admin.dto.ReturnRequestDTO;
import com.capstore.admin.repository.ReturnRequestRepository;

@RestController
@RequestMapping(value = "api/v1/")
public class ReturnRequestController {

	@Autowired
	ReturnRequestRepository returnRequestRepository;
	
	@RequestMapping(value = "return", method = RequestMethod.GET)
	public List<ReturnRequestDTO> list() {
		return returnRequestRepository.findAll();
	}
	
}
import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dao.ILadDAO;
import com.capgemini.las.dao.LadDAO;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LadDTO;



public class LadDAOTest {

	private ILadDAO daoRef;
	
	@Before
	public void setup(){
		System.out.println("DAO instantiated");
		daoRef = new LadDAO();
	}
	
	@After
	public void tearDown(){
		System.out.println("DAO cleaned");
		daoRef = null;
	}
	
	
	@Test
	public void testValidateApplication() throws LoanException{
		
		String status="Applied";
		CustomerDTO cdto = new CustomerDTO();
		cdto.setStatus(status);
		Assert.assertEquals(status, cdto.getStatus());
	}
	
	
	@Test
	public void testGetAllUsers() throws LoanException{
		
		String uname="Rushabh";
		LadDTO ldto = new LadDTO();
		ldto.setUserName(uname);
		Assert.assertEquals(uname, ldto.getUserName());
	}
	
	
}

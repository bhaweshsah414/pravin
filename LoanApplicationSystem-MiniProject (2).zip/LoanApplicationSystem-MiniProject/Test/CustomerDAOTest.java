import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dao.CustomerDAO;
import com.capgemini.las.dao.ICustomerDAO;
import com.capgemini.las.dto.CustomerDTO;

public class CustomerDAOTest {

	private ICustomerDAO daoRef;
	
	@Before
	public void setup(){
		System.out.println("DAO instantiated");
		daoRef = new CustomerDAO();
	}
	
	@After
	public void tearDown(){
		System.out.println("DAO cleaned");
		daoRef = null;
	}
	
	
	@Test
	public void testGetLoanApplied() throws LoanException{
		
		long id = 10008;
		CustomerDTO cdto = new CustomerDTO();
		cdto.setApplicationId(id);
		Assert.assertEquals(id, cdto.getApplicationId());
	}
	
}

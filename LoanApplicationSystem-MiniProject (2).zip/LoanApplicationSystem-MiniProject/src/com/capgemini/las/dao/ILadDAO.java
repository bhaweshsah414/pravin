package com.capgemini.las.dao;

import java.util.List;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LadDTO;

public interface ILadDAO {

	public List<LadDTO> getAllUsers() throws LoanException;
	public List<CustomerDTO> getLoanApplications() throws LoanException;
	public int validateApplication(Long id, String stat) throws LoanException;
	
}

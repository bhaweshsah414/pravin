package com.capgemini.las.dao;

import java.util.List;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public interface ICustomerDAO 
{
	public List<LoanProgramsOfferedDTO> getAllLoanPrograms() throws LoanException;
	public long getLoanApplied(CustomerDTO cdto) throws LoanException;
	public String viewStatus(long applicationId) throws LoanException;

}

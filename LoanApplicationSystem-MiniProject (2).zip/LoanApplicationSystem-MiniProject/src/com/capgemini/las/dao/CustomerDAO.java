package com.capgemini.las.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.las.dbUtils.Log4jHTMLLayout;
import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dbUtils.DBUtils;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;


public class CustomerDAO implements ICustomerDAO{

	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	private Connection dbConnection = null;
	
	private long generateApplicationId() throws LoanException{
		long id=0L;
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e1) {
			System.out.println("Unable to establish connection.");
		} catch (SQLException e1) {
			System.out.println("Unable to generate Application Id");
		}
		String sql = "SELECT SEQ.NEXTVAL FROM DUAL";
		try {
			Statement st = dbConnection.createStatement();
			ResultSet rst = st.executeQuery(sql);
			while(rst.next()){
				 id=rst.getLong(1);
				
			}
			return id;
		} catch (SQLException e) {
			throw new LoanException("Problem in generating course id " + e.getMessage());
		}
	}
	
	@Override
	public List<LoanProgramsOfferedDTO> getAllLoanPrograms() throws LoanException
	{
		String sql="SELECT * FROM LoanProgramsOffered";
		ArrayList<LoanProgramsOfferedDTO> clist = new ArrayList<>();
		
		try {
			dbConnection=DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			System.out.println("Unable to establish connection.");
		} catch (SQLException e) {
			System.out.println("Unable to fetch details.");
		}
		
		try {
			Statement st=dbConnection.createStatement();
			ResultSet rst = st.executeQuery(sql);
			
			while(rst.next()) {
				LoanProgramsOfferedDTO c = new LoanProgramsOfferedDTO();
				c.setProgramName(rst.getString(1));
				c.setDescription(rst.getString(2));
				c.setLoanType(rst.getString(3));
				c.setLoanDuration(rst.getInt(4));
				c.setMinLoanAmount(rst.getDouble(5));
				c.setMaxLoanAmount(rst.getDouble(6));
				c.setRateOfInterest(rst.getDouble(7));
				c.setProofsRequired(rst.getString(8));
				clist.add(c);
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new LoanException();			
		}
		
		
		return clist;
	}
	
	
	
	
	
	@Override
	public long getLoanApplied(CustomerDTO cdto) throws LoanException 
	{
		//String selectQuery = "SELECT APPLICATION_ID FROM LOANAPPLICATION";
		String sql1 = "INSERT INTO LOANAPPLICATION VALUES(?, SYSDATE, ?,?,?,?,?,?,?,'Applied',?)";
		String sql2 = "INSERT INTO CUSTOMERDETAILS VALUES(?,?,?,?,?,?,?,?)";
		cdto.setApplicationId(generateApplicationId());
		
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to insert details. ");
		}
		
		
		try {
			
			PreparedStatement insertStatement1=dbConnection.prepareStatement(sql1);

			insertStatement1.setLong(1, cdto.getApplicationId());
			insertStatement1.setString(2, cdto.getLoanType());
			insertStatement1.setDouble(3, cdto.getLoanAmount());
			insertStatement1.setString(4, cdto.getAddressOfProperty());
			insertStatement1.setDouble(5, cdto.getAnnualFamilyIncome());
			insertStatement1.setString(6, cdto.getDocumentProofsAvailable());
			insertStatement1.setString(7, cdto.getGuaranteeCover());
			insertStatement1.setDouble(8, cdto.getMarketValueOfGuaranteeCover());
			
			insertStatement1.setDate(9, (Date) cdto.getDateOfInterview());
			int rows1=insertStatement1.executeUpdate();
			
			PreparedStatement insertStatement2=dbConnection.prepareStatement(sql2);
			
			insertStatement2.setLong(1, cdto.getApplicationId());
			insertStatement2.setString(2, cdto.getApplicantName());
			
			Date dateOfBirth = new Date(cdto.getDob().getTime());
			insertStatement2.setDate(3, dateOfBirth);
			
			insertStatement2.setString(4, cdto.getMaritalStatus());
			insertStatement2.setLong(5, cdto.getPhoneNumber());
			insertStatement2.setLong(6, cdto.getMobileNumber());
			insertStatement2.setInt(7, cdto.getCountOfDependents());
			insertStatement2.setString(8, cdto.getEmailId());
			int rows2=insertStatement2.executeUpdate();
			
			if(rows1 > 0 && rows2>0){				
				log.info("New row added");
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new LoanException("Unable to insert details. ");
		}
		
		
		
		return cdto.getApplicationId();
	}

	@Override
	public String viewStatus(long applicationId) throws LoanException {
		String sql = "SELECT STATUS FROM LOANAPPLICATION WHERE APPLICATION_ID=?";
		String status=" ";
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to get status details.");
		}

		
		try {
			PreparedStatement findStatement=dbConnection.prepareStatement(sql);
			findStatement.setLong(1, applicationId);
			ResultSet rst = findStatement.executeQuery();
			
			while(rst.next()) {
				status=rst.getString(1);
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new LoanException();			
		}
		
		
		
		
		return status;
	}

	

}

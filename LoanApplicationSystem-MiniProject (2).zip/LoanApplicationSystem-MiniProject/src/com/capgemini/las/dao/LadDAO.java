package com.capgemini.las.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.las.dbUtils.Log4jHTMLLayout;
import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dbUtils.DBUtils;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LadDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public class LadDAO implements ILadDAO{
	
	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	
	private Connection dbConnection = null;

	@Override
	public List<LadDTO> getAllUsers() throws LoanException {
		
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e1) {
			System.out.println("Unable to establish connection.");
		} catch (SQLException e1) {
			System.out.println("Unable to login");
		}
		
		String sql = "SELECT * FROM USERS";		
		ArrayList<LadDTO> llist = new ArrayList<>();
		try {
			Statement selectStatement = dbConnection.createStatement();
			ResultSet rst = selectStatement.executeQuery(sql);
			

			while(rst.next()) {
				LadDTO l = new LadDTO();
				l.setUserName(rst.getString(1));
				l.setPassword(rst.getString(2));
				l.setRole(rst.getString(3));
				llist.add(l);
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage());
			System.out.println("Unable to login.");
		}
		
		
				
		return llist;
	}

	@Override
	public List<CustomerDTO> getLoanApplications() throws LoanException {
		
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e1) {
			System.out.println("Unable to establish connection.");
		} catch (SQLException e1) {
			System.out.println("Unable to login");
		}
		
		String sql1 = "SELECT * FROM LOANAPPLICATION";
		String sql2 = "SELECT APPLICANT_NAME, DATE_OF_BIRTH, MARITAL_STATUS, "
				+ "PHONE_NUMBER, MOBILE_NUMBER, COUNTOFDEPENDENTS, EMAIL_ID FROM CUSTOMERDETAILS";
		
		ArrayList<CustomerDTO> llist = new ArrayList<>();
		
		try {
			Statement selectStatement1 = dbConnection.createStatement();
			ResultSet rst1 = selectStatement1.executeQuery(sql1);
			Statement selectStatement2 = dbConnection.createStatement();
			ResultSet rst2 = selectStatement2.executeQuery(sql2);
			
			while(rst1.next() && rst2.next()) {
				CustomerDTO cdto = new CustomerDTO();
				cdto.setApplicationId(rst1.getLong(1));
				Date applicationDateSQL=rst1.getDate(2);
				java.util.Date applicationDate = new java.util.Date(applicationDateSQL.getTime());
				cdto.setApplicationDate(applicationDate);
				cdto.setLoanType(rst1.getString(3));
				cdto.setLoanAmount(rst1.getDouble(4));
				cdto.setAddressOfProperty(rst1.getString(5));
				cdto.setAnnualFamilyIncome(rst1.getDouble(6));
				cdto.setDocumentProofsAvailable(rst1.getString(7));
				cdto.setGuaranteeCover(rst1.getString(8));
				cdto.setMarketValueOfGuaranteeCover(rst1.getDouble(9));
				cdto.setStatus(rst1.getString(10));
				/*Date interviewDateSQL = rst1.getDate(11);
				java.util.Date interviewDate = new java.util.Date(interviewDateSQL.getTime());
				cdto.setDateOfInterview(interviewDate);*/
				cdto.setDateOfInterview(rst1.getDate(11));
				
				cdto.setApplicantName(rst2.getString(1));
				Date dobSQL = rst2.getDate(2);
				java.util.Date dob = new java.util.Date(dobSQL.getTime());
				
				cdto.setDob(dob);
				cdto.setMaritalStatus(rst2.getString(3));
				cdto.setPhoneNumber(rst2.getLong(4));
				cdto.setMobileNumber(rst2.getLong(5));
				cdto.setCountOfDependents(rst2.getInt(6));
				cdto.setEmailId(rst2.getString(7));
				llist.add(cdto);
			}
			
		} catch (SQLException e) {
			log.error(e.getMessage());
			System.out.println("Unable to login");
		} catch (ParseException e) {
			log.error(e.getMessage());
			System.out.println("Incorrect date format");
		}
		
		
		return llist;
	}

	@Override
	public int validateApplication(Long id, String stat) throws LoanException {
		int i=0;
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e1) {
			System.out.println("Unable to establish connection.");
		} catch (SQLException e1) {
			System.out.println("Unable to login");
		}
		
		String sql = "UPDATE LOANAPPLICATION SET STATUS=? WHERE APPLICATION_ID=?";
		try {
			PreparedStatement pst = dbConnection.prepareStatement(sql);
			pst.setString(1, stat);
			pst.setLong(2, id);
			int rows=pst.executeUpdate();
			
			if(rows > 0){				
				log.info("Status updated");
			}
			
			i=1;
		} catch (SQLException e) {
			log.error(e.getMessage());
			System.out.println("Unable to update.");
		}
		
		
		return i;
	}

}

package com.capgemini.las.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.las.dbUtils.Log4jHTMLLayout;
import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dbUtils.DBUtils;
import com.capgemini.las.dto.ApprovedLoansDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public class AdminDAO implements IAdminDAO{
	
	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	
	private Connection dbConnection = null;

	@Override
	public String addLoanProgram(LoanProgramsOfferedDTO lpd) throws LoanException {
	
		String sql="INSERT INTO LOANPROGRAMSOFFERED VALUES('LOAN',?,?,?,?,?,?,?)"; 
		String loanType=" ";
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to insert details. ");
		}
		
		
		try {
			
			PreparedStatement insertStatement1=dbConnection.prepareStatement(sql);

			insertStatement1.setString(1, lpd.getDescription());
			insertStatement1.setString(2, lpd.getLoanType());
			insertStatement1.setInt(3, lpd.getLoanDuration());
			insertStatement1.setDouble(4, lpd.getMinLoanAmount());
			insertStatement1.setDouble(5, lpd.getMaxLoanAmount());
			insertStatement1.setDouble(6, lpd.getRateOfInterest());
			insertStatement1.setString(7, lpd.getProofsRequired());
			int rows=insertStatement1.executeUpdate();
			if(rows > 0){				
				log.info("New row added");
			}
			loanType=lpd.getLoanType();
			
		} catch (SQLException e) {
			log.error(e.getMessage());	
			throw new LoanException("Unable to insert details. ");
		}
		
		
		
		return loanType;
	}

	@Override
	public String updateLoanProgram(LoanProgramsOfferedDTO lpd, String choose) throws LoanException {
		
		String sql="UPDATE LOANPROGRAMSOFFERED SET DESCRIPTION=?, DURATIONINYEARS=?,"
				+ " MINLOANAMOUNT=?, MAXLOANAMOUNT=?, RATEOFINTEREST=?, PROOFS_REQUIRED=? WHERE LOANTYPE=?"; 
		
		String loanType=" ";
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to insert details. ");
		}
		
		
		try {
			
			PreparedStatement insertStatement1=dbConnection.prepareStatement(sql);

			insertStatement1.setString(1, lpd.getDescription());			
			insertStatement1.setInt(2, lpd.getLoanDuration());
			insertStatement1.setDouble(3, lpd.getMinLoanAmount());
			insertStatement1.setDouble(4, lpd.getMaxLoanAmount());
			insertStatement1.setDouble(5, lpd.getRateOfInterest());
			insertStatement1.setString(6, lpd.getProofsRequired());
			insertStatement1.setString(7, choose);
			int rows=insertStatement1.executeUpdate();
			if(rows > 0){				
				log.info("Row updated");
			}
			
			loanType=choose;
			
		} catch (SQLException e) {
			log.error(e.getMessage());	
			throw new LoanException("Unable to insert details. ");
		}
		
		
		
		return loanType;
		
		
	}

	@Override
	public String deleteLoanProgram(String choose1) throws LoanException {
		String sql="DELETE FROM LOANPROGRAMSOFFERED WHERE LOANTYPE=?"; 
		
		String loanType=" ";
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to insert details. ");
		}
		
		
		try {
			
			PreparedStatement insertStatement1=dbConnection.prepareStatement(sql);

			insertStatement1.setString(1, choose1);			
			
			int rows=insertStatement1.executeUpdate();
			if(rows > 0){				
				log.info("Row deleted");
			}
			
			loanType=choose1;
			
		} catch (SQLException e) {
			log.error(e.getMessage());	
			throw new LoanException("Unable to insert details. ");
		}
		
		
		
		return loanType;
	}

	@Override
	public int approveLoan(ApprovedLoansDTO aloan, long id) throws LoanException {
		int i=0;
		String appName=" ";
		String sql="INSERT INTO APPROVEDLOANS VALUES(?,?,?,?,?,?,?,?)"; 
		
		String getName="SELECT APPLICANT_NAME FROM CUSTOMERDETAILS WHERE APPLICATION_ID=?";
		String loanType=" ";
		try 
		{
			
			dbConnection = DBUtils.getConnection();
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Connection to database could not be established.");
		} catch (SQLException e) 
		{
			System.out.println("Unable to insert details. ");
		}
		
		
		try {
			PreparedStatement insertStatement1=dbConnection.prepareStatement(getName);
			
			insertStatement1.setLong(1, id);
			ResultSet rst=insertStatement1.executeQuery();
			
			
			while(rst.next()){
				appName=rst.getString(1);
			}
			PreparedStatement insertStatement2=dbConnection.prepareStatement(sql);

			
			insertStatement2.setLong(1, id);
			insertStatement2.setString(2, appName);
			insertStatement2.setDouble(3, aloan.getAmountOfLoanGranted());
			insertStatement2.setDouble(4, aloan.getMonthlyInstallment());
			insertStatement2.setDouble(5, aloan.getYearsTimePeriod());
			insertStatement2.setDouble(6, aloan.getDownPayment());
			insertStatement2.setDouble(7, aloan.getRateOfInterest());
			insertStatement2.setDouble(8, aloan.getTotalAmountPayable());
			
			int rows=insertStatement2.executeUpdate();
			if(rows > 0){				
				log.info("New row added");
			}
			i=1;
			
		} catch (SQLException e) {
			log.error(e.getMessage());	
			throw new LoanException("Unable to insert details. ");
		}
		
		
		
		
		return i;
		
	}

}

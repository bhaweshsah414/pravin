package com.capgemini.las.Exception;

public class LoanException extends Exception{

	public LoanException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoanException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LoanException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}

package com.capgemini.las.ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dto.ApprovedLoansDTO;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LadDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;
import com.capgemini.las.service.AdminService;
import com.capgemini.las.service.CustomerService;
import com.capgemini.las.service.IAdminService;
import com.capgemini.las.service.ICustomerService;
import com.capgemini.las.service.ILadService;
import com.capgemini.las.service.LadService;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class LoanMain {

	public static void main(String[] args) {
		
	Scanner sc=new Scanner(System.in);
	ICustomerService cser=new CustomerService();
	IAdminService adser = new AdminService();
	int option = 0;
	try{
	while (true) {

		// show menu
		System.out.println();
		System.out.println();
		System.out.println("   LOAN APPLICATION SYSTEM  ");
		System.out.println("_______________________________\n");

		System.out.println("1. View and apply for loan.");
		System.out.println("2. View all applied Loan applications.");
		System.out.println("3. Alter Loan programs/Approve or Reject loan application.");
		System.out.println("4. Exit");
		System.out.println("________________________________");
		System.out.println("Select an option:");
		// accept option

		option = sc.nextInt();
		
		try {
			//option = sc.nextInt();
			
			switch (option) {
			
			case 1:	//Customer Application
				while(true){
				List<LoanProgramsOfferedDTO> clist = cser.getAllLoanPrograms();
				if(clist.size()==0){
					System.out.println("No loan programs available.");
					break;
				}
				
				System.out.println("Following Loan programs are available:");
				int i=1;
				for(LoanProgramsOfferedDTO c:clist)
				{
					System.out.println(i + ". " + c.getLoanType() + "\n\tDescription: " + c.getDescription()
					+ "\n\tLoan Duration: " + c.getLoanDuration() + " months" + "\n\tMinimum Loan Amount: Rs. " 
					+ c.getMinLoanAmount()	+ "\n\tMaximum Loan Amount: Rs. " + c.getMaxLoanAmount()
					+ "\n\tRate of Interest: " + c.getRateOfInterest()  + " %"+ "\n\tProofs Required: " 
					+ c.getProofsRequired());
					System.out.println("****************************************************");
					i++;
				}
				
				System.out.println("1. Apply for loan.");
				System.out.println("2. View loan application status.");
				System.out.println("3. Exit.");
				System.out.println("Enter your choice.");
				int choice=sc.nextInt();
				
				switch(choice)
				{
				case 1:		
					CustomerDTO cdto=new CustomerDTO();
					System.out.println("Enter your name:");
					String name=sc.next();
					System.out.println("Date of birth(dd-mm-yyyy):");
					String dob=sc.next();
					System.out.println("Marital status:");
					String mStatus=sc.next();
					System.out.println("Phone number:");
					long pNumber=sc.nextLong();
					System.out.println("Mobile number:");
					long mNumber=sc.nextLong();
					System.out.println("Count of Dependents:");
					int dependents=sc.nextInt();
					System.out.println("Email ID:");
					String email=sc.next();
					
					System.out.println("Enter a loan type:");
					String loanType=sc.next();
					System.out.println("Loan amount kiti pahije:");
					double loanAmount=sc.nextDouble();
					System.out.println("Provide a guarantee cover:");
					String guaranteeCover=sc.next();
					System.out.println("Address of the property:");
					String addressOfProperty=sc.next();
					System.out.println("Market value of the property:");
					double marketValueOfProperty=sc.nextDouble();
					System.out.println("Annual family income:");
					double annualFamilyIncome=sc.nextDouble();
					System.out.println("Document proofs available");
					String documentProofsAvailable=sc.next();
					
					try{
					cdto.setApplicantName(name);
					Date dateOfBirth = new SimpleDateFormat("dd-mm-yyyy").parse(dob);
					cdto.setDob(dateOfBirth);
					cdto.setMaritalStatus(mStatus);
					cdto.setPhoneNumber(pNumber);
					cdto.setMobileNumber(mNumber);
					cdto.setCountOfDependents(dependents);
					cdto.setEmailId(email);
					
										
					
					int check=validateLoan(loanType);
					if(check!=1){
						System.out.println("Please enter loan type from given loan programs.");
						continue;
					}
					else{
						cdto.setLoanType(loanType);
					}
					
					cdto.setLoanAmount(loanAmount);
					cdto.setGuaranteeCover(guaranteeCover);
					cdto.setAddressOfProperty(addressOfProperty);
					cdto.setMarketValueOfGuaranteeCover(marketValueOfProperty);
					cdto.setAnnualFamilyIncome(annualFamilyIncome);
					cdto.setDocumentProofsAvailable(documentProofsAvailable);
					
					
					
					long appId=cser.getLoanApplied(cdto);
					System.out.println("Your loan application is successfully applied with Applicant Id: " + appId);
					System.out.println();
					
					}
					catch (java.text.ParseException e) {
						System.out.println("Incorrect date format. Enter date in specified format.");
					}
					
					break;
				
				case 2:
					System.out.println("Enter your application Id:");
					long id=sc.nextLong();
					String status=cser.viewStatus(id);

					
					if(status.equals(" ")){
						System.out.println("Incorrect application ID. Please try again.");
						System.out.println();
						break;
					}
					else{
						System.out.println("Your application status is: " + status);
						System.out.println();
					}	
						
					
					
				
					break;
				case 3:
					System.exit(0);
					
				default: System.out.println("Enter a valid option[1-2]");
					
				}
			
				}
			
			case 2:	//LAD Login
				while(true){
					List<LoanProgramsOfferedDTO> clist = cser.getAllLoanPrograms();
					if(clist.size()==0){
						System.out.println("No loan programs available.");
						break;
					}
					
					System.out.println("Following Loan programs are available:");
					int i=1;
					for(LoanProgramsOfferedDTO c:clist)
					{
						System.out.println(i + ". " + c.getLoanType() 
						+ "\n\tDescription: " + c.getDescription()
						+ "\n\tLoan Duration: " + c.getLoanDuration() +" months" 
						+ "\n\tMinimum Loan Amount: Rs. " + c.getMinLoanAmount()	
						+ "\n\tMaximum Loan Amount: Rs. " + c.getMaxLoanAmount()
						+ "\n\tRate of Interest: " + c.getRateOfInterest()  + " %"
						+ "\n\tProofs Required: " + c.getProofsRequired());
						System.out.println("****************************************************");
						i++;
					}
								
					
					while(true){
						
						System.out.println("1. View Loan applications.");
						System.out.println("2. Accept/Reject a Loan application.");
						System.out.println("3. Exit.");
						System.out.println("Enter your choice.");
						int choice=sc.nextInt();
						int check=0;
						if(choice==1 || choice==2){
						LadDTO ldto = new LadDTO();
						System.out.println("Enter username and password to login");
						System.out.println("User name:");
						String uname=sc.next();
						System.out.println("Password:");
						String pass=sc.next();
						check = validateLADLogin(uname, pass);
						if(check==1){
							System.out.println("Login successful");
						}
						}
					switch(choice)
					{
					case 1:
						
						
						if(check!=1){
							System.out.println("Unauthorized user, access denied.");
							break;
						}
						else{
							
							System.out.println("__________________________________________________________");
							System.out.println("Aplicants Details for Loan::");
							System.out.println("__________________________________________________________");
							//remaining code here
							ILadService ladser = new LadService();
							List<CustomerDTO> c1list = ladser.getLoanApplications();
							
							
							
							for(CustomerDTO c1:c1list)
							{
								System.out.println("Application ID::"+c1.getApplicationId() 
								+"\n\tApplication Date: "+c1.getApplicationDate()
								+"\n\tApplicant Name: "+c1.getApplicantName()
								+"\n\tDate Of Birth: " +c1.getDob()
								+"\n\tMarital Status: "+c1.getMaritalStatus()
								+"\n\tPhone Number: "+c1.getPhoneNumber()
								+"\n\tMobile Number: "+c1.getMobileNumber()
								+"\n\tCount Of Dependents: "+c1.getCountOfDependents()
								+"\n\tEmail Id: "+c1.getEmailId()
								+"\n\tLoan Type: "+c1.getLoanType()
								+"\n\tLoan Amount: "+c1.getLoanAmount()
								+"\n\tAddress Of Property: "+c1.getAddressOfProperty()
								+"\n\tAnnual Family Income: "+c1.getAnnualFamilyIncome()
								+"\n\tDocument Proofs Available: "+c1.getDocumentProofsAvailable()
								+"\n\tGuarantee Cover: "+c1.getGuaranteeCover()
								+"\n\tMarketValue Of Guarantee Cover: "+c1.getMarketValueOfGuaranteeCover()
								+"\n\tStatus: "+c1.getStatus()
								+"\n\tDate Of Interview: " + c1.getDateOfInterview()
								
								);
								System.out.println();
								System.out.println("__________________________________________________________");
								System.out.println();
							}
							
							
						}
					
						break;
					
					case 2:
						
						if(check!=1){
							System.out.println("Unauthorized user, access denied.");
							choice=-1;
							break;
						}
						else{
							
							System.out.println("Enter application ID whose application is to be evaluated: ");
							long id=sc.nextLong();
							String status=cser.viewStatus(id);

							
							if(status.equals(" ")){
								System.out.println("Incorrect application ID. Please try again.");
								System.out.println();
								
							}
							else{
								
								if(status.equalsIgnoreCase("Applied")){
									System.out.println("Enter a choice:\n1. Accept the application.");
									System.out.println("2. Reject the application");
									System.out.println("3. Exit");
									int temp = sc.nextInt();
									String stat="";
									int a=0;
									ILadService lService = new LadService();
									switch(temp){
									case 1:
										stat = "Accepted";		
										
										a=lService.validateApplication(id, stat);
										if(a==1){
											System.out.println("Application with id " + id + " updated successfully");
										}else{
											System.out.println("Unable to access.");
										}
										break;
									case 2:
										stat = "Rejected";
														
										a=lService.validateApplication(id, stat);
										if(a==1){
											System.out.println("Application with id " + id + " updated successfully");
										}else{
											System.out.println("Unable to access.");
										}
										
										break;
									case 3:System.exit(0);
									default:System.out.println("Enter a valid choice[1-3]");
									
									}
								}else{
									System.out.println("The application status is already: " + status);
								}

								
							choice=3;	
							break;	
								
							}
							
							
							
						}
						
						
						
						break;
						
					case 3:
						System.exit(0);
					
					case -1: break;
					
					default: System.out.println("Enter a valid option[1-3]");	
					
					}
					}			
				}
				
			case 3:	//Admin Login
				int check=0;
				System.out.println("Enter username and password to login");
				System.out.println("User name:");
				String uname=sc.next();
				System.out.println("Password:");
				String pass=sc.next();
				check = validateAdminLogin(uname, pass);
				if(check==1){
					System.out.println("Login successful");
				}
				
				while(true) {
					if(check!=1){
						System.out.println("Unauthorized user, access denied.");
						break;
					}
					
					System.out.println("Enter your choice.");
					System.out.println("1. Add/Update/Delete a loan program.");
					System.out.println("2. Approve/Reject a Loan application.");
					System.out.println("3. Exit.");
					
					int choice=sc.nextInt();
					
					
					if(choice==1 || choice==2){
					LadDTO ldto = new LadDTO();
					
					}
					
					switch(choice)
					{
					case 1:
						if(check!=1){
							System.out.println("Unauthorized user, access denied.");
							break;
						}
						else{
						
						System.out.println("1. Add a loan program.");
						System.out.println("2. Update a loan program.");
						System.out.println("3. Delete a loan program.");
						System.out.println("4. Exit");
						int opt = sc.nextInt();
						
						if(opt>=1 && opt<4)
						{
							List<LoanProgramsOfferedDTO> clist = cser.getAllLoanPrograms();
							if(clist.size()==0){
								System.out.println("No loan programs available.");
								break;
							}
							
							System.out.println("Following Loan programs are available:");
							int i=1;
							for(LoanProgramsOfferedDTO c:clist)
							{
								System.out.println(i + ". " + c.getLoanType());
								i++;
							}
							System.out.println();
						}
						
						LoanProgramsOfferedDTO lpd = new LoanProgramsOfferedDTO();
						switch(opt){
						case 1:
						
							System.out.println("Enter Loan type:");
							String lt=sc.next();
							String capsLoanType=lt.toUpperCase();
							lpd.setLoanType(capsLoanType);
							System.out.println("Enter Loan description:");
							lpd.setDescription(sc.next());
							System.out.println("Enter duration of the loan(in years):");
							lpd.setLoanDuration(sc.nextInt());
							System.out.println("Enter minimum amount required:");
							lpd.setMinLoanAmount(sc.nextDouble());
							System.out.println("Enter maximum amount required:");
							lpd.setMaxLoanAmount(sc.nextDouble());
							System.out.println("Enter rate of interest:");
							lpd.setRateOfInterest(sc.nextDouble());
							System.out.println("Enter documents required:");
							lpd.setProofsRequired(sc.next());
							
							String addedLoanType=adser.addLoanProgram(lpd);
							if(addedLoanType.equals(" ")){
								System.out.println("Unable to add loan type");
							}
							else{
							System.out.println("New loan program added with loan type " + addedLoanType);
							}
							
							break;
						case 2:
							System.out.println("Choose a loan type to be updated");
							String lt1=sc.next();
							String capsLoanType1=lt1.toUpperCase();
							lpd.setLoanType(capsLoanType1);
							int num=validateLoan(lt1);
							List<LoanProgramsOfferedDTO> clist = cser.getAllLoanPrograms();
							
							if(num!=1){
								System.out.println("Please enter loan type from given loan programs.");
								continue;
							}
							else{
								System.out.println("Enter Loan description:");
								lpd.setDescription(sc.next());
								System.out.println("Enter duration of the loan(in years):");
								lpd.setLoanDuration(sc.nextInt());
								System.out.println("Enter minimum amount required:");
								lpd.setMinLoanAmount(sc.nextDouble());
								System.out.println("Enter maximum amount required:");
								lpd.setMaxLoanAmount(sc.nextDouble());
								System.out.println("Enter rate of interest:");
								lpd.setRateOfInterest(sc.nextDouble());
								System.out.println("Enter documents required:");
								lpd.setProofsRequired(sc.next());
								
								String updatedLoanType=adser.updateLoanProgram(lpd, capsLoanType1);
								if(updatedLoanType.equals(" ")){
									System.out.println("Unable to update loan type");
								}
								else{
									System.out.println("Loan type " + updatedLoanType + " updated successfully.");
								}
							
							}
							break;
						case 3:
							System.out.println("Enter a loan program to be deleted");
							String lt2=sc.next();
							String capsLoanType2=lt2.toUpperCase();
							lpd.setLoanType(capsLoanType2);
							int num1=validateLoan(lt2);
							List<LoanProgramsOfferedDTO> clist1 = cser.getAllLoanPrograms();
							
							
							if(num1!=1){
								System.out.println("Please enter loan type from given loan programs.");
								continue;
							}
							
							else{


							String deletedLoanType=adser.deleteLoanProgram(capsLoanType2);
							
							if(deletedLoanType.equals(" ")){
								System.out.println("Unable to delete loan type");
							}
							else{
								System.out.println("Loan type " + deletedLoanType + " deleted successfully.");
							}
							
							}
							break;
						case 4: 
							System.exit(0);
						
							
							
						default:
							System.out.println("Enter a valid option[1-4]");
						
						}
						}
						
					
						break;
					case 2:	// Fuctionality to approve/Reject
						
						if(check!=1){
							System.out.println("Unauthorized user, access denied.");
							choice=-1;
							break;
						}
						else{
							
							System.out.println("Enter application ID whose application is to be evaluated: ");
							long id=sc.nextLong();
							String status=cser.viewStatus(id);

							
							if(status.equals(" ")){
								System.out.println("Incorrect application ID. Please try again.");
								System.out.println();
								
							}
							else{
								
								if(status.equalsIgnoreCase("Accepted")){
									System.out.println("Enter a choice:\n1. Approve the application.");
									System.out.println("2. Reject the application");
									System.out.println("3. Exit");
									int temp = sc.nextInt();
									String stat="";
									int a=0;
									ILadService lService = new LadService();
									switch(temp){
									case 1:
										stat = "Approved";		
										
										a=lService.validateApplication(id, stat);
										if(a==1){
											ApprovedLoansDTO aloan = new ApprovedLoansDTO();
											IAdminService iser= new AdminService();
											System.out.println("Enter amount of loan to be granted:");
											aloan.setAmountOfLoanGranted(sc.nextDouble());
											System.out.println("Enter monthly installment:");
											aloan.setMonthlyInstallment(sc.nextDouble());
											System.out.println("Enter duration in years:");
											aloan.setYearsTimePeriod(sc.nextInt());
											System.out.println("Enter down payment:");
											aloan.setDownPayment(sc.nextDouble());
											System.out.println("Enter rate of interest:");
											aloan.setRateOfInterest(sc.nextDouble());
											System.out.println("Enter total amount:");
											aloan.setTotalAmountPayable(sc.nextDouble());
											
											
											int temp1=iser.approveLoan(aloan, id);
											if(temp1==1){
											System.out.println("Application with id " + id + " updated successfully");
											}
											else{
												System.out.println("Unable to update the loan application");
											}
											}else{
											System.out.println("Unable to access.");
										}
										
										
										
										break;
									case 2:
										stat = "Rejected";
														
										a=lService.validateApplication(id, stat);
										if(a==1){
											System.out.println("Application with id " + id + " updated successfully");
										}else{
											System.out.println("Unable to access.");
										}
										
										break;
									case 3:System.exit(0);
									default:System.out.println("Enter a valid choice[1-3]");
									
									}
								}else{
									System.out.println("The application status is already: " + status);
								}

								
								
							break;	
								
							}
							
							
							
						}
						
						
						
						break;
						
						
						
						
					case 3:
						System.exit(0);
					default:
						System.out.println("Enter a valid option[1-3]");	
					}
					
					
				}
				break;
			case 4:	
				System.exit(0);
				
			default:
				System.out.println("Enter a valid option[1-4]");	
				
			}
			}
			 catch (LoanException e) {
				System.out.println("Unable_to_fetch_details.");
			}
		
		}//end of while loop
	
		}
		catch(InputMismatchException e){
		System.out.println("Please enter a numeric value");
		
	}
	
	}




	private static int validateLoan(String loanType) {
		ICustomerService cser=new CustomerService();
		
		int i=0;
		List<LoanProgramsOfferedDTO> clist;
		try {
			clist = cser.getAllLoanPrograms();
			
			for(LoanProgramsOfferedDTO c:clist)
			{
				if(loanType.equalsIgnoreCase(c.getLoanType())){
					i=1;
					break;
				}
				else{
					i=-1;
				}	
				
			}
		} catch (LoanException e) {
			System.out.println("Unable to fetch loan programs");
		}
		return i;
		
		
	}
	
	
	private static int validateLADLogin(String uname, String password){
		ILadService lser = new LadService();
		int i=0;
		List<LadDTO> llist;
		
		try {
			llist = lser.getAllUsers();
			
			for(LadDTO l:llist)
			{
				if(uname.equals(l.getUserName()) && password.equals(l.getPassword()) && l.getRole().equals("LAD")){
					i=1;
					break;
				}
				else{
					i=-1;
				}	
				
			}
		} catch (LoanException e) {
			System.out.println("Unable to connect.");
		}
		
		return i;
	}
	
	

	private static int validateAdminLogin(String uname, String password) {
		
		ILadService lser = new LadService();
		int i=0;
		List<LadDTO> llist;
		
		try {
			llist = lser.getAllUsers();
			
			for(LadDTO l:llist)
			{
				if(uname.equals(l.getUserName()) && password.equals(l.getPassword()) && l.getRole().equals("admin")){
					i=1;
					break;
				}
				else{
					i=-1;
				}	
				
			}
		} catch (LoanException e) {
			System.out.println("Unable to connect.");
		}
		
		return i;
		
	}

	
	
}
package com.capgemini.las.service;

import java.util.List;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dao.CustomerDAO;
import com.capgemini.las.dao.ICustomerDAO;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public class CustomerService implements ICustomerService{

	ICustomerDAO cdao=new CustomerDAO();
	
	@Override
	public List<LoanProgramsOfferedDTO> getAllLoanPrograms() throws LoanException{
		return cdao.getAllLoanPrograms();
	}
	
	
	@Override
	public long getLoanApplied(CustomerDTO cdto) throws LoanException
	{
		return cdao.getLoanApplied(cdto);
	}


	@Override
	public String viewStatus(long applicationId) throws LoanException 
	{
		return cdao.viewStatus(applicationId);
	}

	

}

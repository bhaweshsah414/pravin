package com.capgemini.las.service;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dto.ApprovedLoansDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public interface IAdminService {

	public String addLoanProgram(LoanProgramsOfferedDTO lpd) throws LoanException;
	public String updateLoanProgram(LoanProgramsOfferedDTO lpd, String choose) throws LoanException;
	public String deleteLoanProgram(String choose1) throws LoanException;
	public int approveLoan(ApprovedLoansDTO aloan, long id) throws LoanException;
}

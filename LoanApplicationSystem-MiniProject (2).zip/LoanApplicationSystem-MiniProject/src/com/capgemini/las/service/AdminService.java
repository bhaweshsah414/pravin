package com.capgemini.las.service;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dao.AdminDAO;
import com.capgemini.las.dao.IAdminDAO;
import com.capgemini.las.dto.ApprovedLoansDTO;
import com.capgemini.las.dto.LoanProgramsOfferedDTO;

public class AdminService implements IAdminService{
	
	IAdminDAO idao = new AdminDAO();

	@Override
	public String addLoanProgram(LoanProgramsOfferedDTO lpd) throws LoanException{
		return idao.addLoanProgram(lpd);
	}

	@Override
	public String updateLoanProgram(LoanProgramsOfferedDTO lpd, String choose) throws LoanException{
		return idao.updateLoanProgram(lpd, choose);
	}

	@Override
	public String deleteLoanProgram(String choose1) throws LoanException{
		return idao.deleteLoanProgram(choose1);
		
	
	}

	@Override
	public int approveLoan(ApprovedLoansDTO aloan, long id) throws LoanException {
		
		return idao.approveLoan(aloan, id);
	}

}

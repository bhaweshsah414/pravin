package com.capgemini.las.service;

import java.util.List;

import com.capgemini.las.Exception.LoanException;
import com.capgemini.las.dao.ILadDAO;
import com.capgemini.las.dao.LadDAO;
import com.capgemini.las.dto.CustomerDTO;
import com.capgemini.las.dto.LadDTO;

public class LadService implements ILadService{
	
	ILadDAO ldao = new LadDAO();

	@Override
	public List<LadDTO> getAllUsers() throws LoanException {
		return ldao.getAllUsers();
	}

	@Override
	public List<CustomerDTO> getLoanApplications() throws LoanException {
		return ldao.getLoanApplications();
	}

	@Override
	public int validateApplication(Long id, String stat) throws LoanException {
		return ldao.validateApplication(id, stat);
	}

}

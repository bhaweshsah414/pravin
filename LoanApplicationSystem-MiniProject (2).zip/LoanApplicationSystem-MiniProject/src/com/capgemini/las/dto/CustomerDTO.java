package com.capgemini.las.dto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomerDTO
{

	// CustomerDetails fields
	private long applicationId;
	private String applicantName;
	private Date dob;
	private String maritalStatus;
	private long phoneNumber;
	private long mobileNumber;
	private int countOfDependents;
	private String emailId;
	
	// LoanApplication fields
	private Date applicationDate;
	private String loanType;
	private double loanAmount;
	private String addressOfProperty;
	private double annualFamilyIncome;
	private String documentProofsAvailable;
	private String guaranteeCover;
	private double marketValueOfGuaranteeCover;
	private String status;
	private Date dateOfInterview;
	
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicationName) {
		this.applicantName = applicationName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) throws ParseException {
		/*this.dob = new SimpleDateFormat("dd-mm-yyyy").parse(dob);*/
		this.dob=dob;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getCountOfDependents() {
		return countOfDependents;
	}
	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Date getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getAddressOfProperty() {
		return addressOfProperty;
	}
	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}
	public double getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}
	public void setAnnualFamilyIncome(double annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}
	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}
	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}
	public String getGuaranteeCover() {
		return guaranteeCover;
	}
	public void setGuaranteeCover(String guaranteeCover) {
		this.guaranteeCover = guaranteeCover;
	}
	public double getMarketValueOfGuaranteeCover() {
		return marketValueOfGuaranteeCover;
	}
	public void setMarketValueOfGuaranteeCover(double marketValueOfGuaranteeCover) {
		this.marketValueOfGuaranteeCover = marketValueOfGuaranteeCover;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDateOfInterview() {
		return dateOfInterview;
	}
	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}
	
	
}

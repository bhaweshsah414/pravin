package com.capgemini.las.dto;

public class ApprovedLoansDTO {

	private long applicationId;
	private String customerName;
	private double  amountOfLoanGranted;
	private double  monthlyInstallment;
	private int  yearsTimePeriod; 
	private double  downPayment;
	private double  rateOfInterest;
	private double  totalAmountPayable;
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}
	public void setAmountOfLoanGranted(double amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}
	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	public void setMonthlyInstallment(double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}
	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}
	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}
	public double getDownPayment() {
		return downPayment;
	}
	public void setDownPayment(double downPayment) {
		this.downPayment = downPayment;
	}
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getTotalAmountPayable() {
		return totalAmountPayable;
	}
	public void setTotalAmountPayable(double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}
	

}

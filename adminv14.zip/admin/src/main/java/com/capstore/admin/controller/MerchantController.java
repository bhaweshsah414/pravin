package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CustomerDTO;
import com.capstore.admin.model.MerchantDTO;
import com.capstore.admin.repository.CustomerRepository;
import com.capstore.admin.repository.MerchantRepository;

@RestController
@RequestMapping("api/v1/")
public class MerchantController {
	
	@Autowired
	private MerchantRepository merchantRepository;

	@RequestMapping(value = "adminPage/findAllMerchant", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<MerchantDTO> list() {
		return merchantRepository.findAll();
	}

	@RequestMapping(value = "adminPage/addMerchant", method = RequestMethod.POST)
	public MerchantDTO create(@RequestBody MerchantDTO merchantDTO) {
		return merchantRepository.saveAndFlush(merchantDTO);
	}

	@RequestMapping(value = "adminPage/findMerchantById/{id}", method = RequestMethod.GET)
	public MerchantDTO get(@PathVariable Integer id) {
		return merchantRepository.findOne(id);
	}
	
	@RequestMapping(value = "adminPage/DeleteMerchantById/{id}", method = RequestMethod.DELETE)
	public MerchantDTO delete(@PathVariable Integer id) {
		MerchantDTO existingMerchant = merchantRepository.findOne(id);
		merchantRepository.delete(existingMerchant);
		return existingMerchant;
	}

}

package com.capstore.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.admin.model.ProductDTO;

public interface ProductRepository extends JpaRepository<ProductDTO, Integer>  
{
	

}

package com.capstore.admin.repository;

public interface OrderRepository {

}
